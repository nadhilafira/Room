<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['cas_server_url'] = 'https://sso.ui.ac.id/cas2';
$config['phpcas_path'] = 'C:\Users\Ruki\Documents\UniServerZ\www\room\application\libraries\phpCAS';
$config['cas_disable_server_validation'] = TRUE;
$config['cas_debug'] = TRUE; // <--  use this to enable phpCAS debug mode
