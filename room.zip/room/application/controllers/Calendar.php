<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Calendarmodel');
		if($this->session->login !== true) redirect(base_url('login'));
	}

	public function index() {
		// if($this->session->role == 'admin'){
			$arr = $this->Calendarmodel->getAll();
		// }elseif($this->session->role == 'dosen'){
			// $arr = $this->Calendarmodel->getAll('',$this->session->id,'');
		// }
		for($i=0;$i<count($arr);$i++){ //event text color? Menanti pengecekan','Ditolak','Ruang OK','Ruang OK, undangan sedang dibuat','Undangan sudah dikirim','Selesai, menunggu notulen','Selesai, notulen OK'
			if($arr[$i]->borderColor=='Menanti pengecekan'){
				$arr[$i]->borderColor='yellow';
			}elseif($arr[$i]->borderColor=='Ditolak'){
				$arr[$i]->borderColor='red';
			}elseif($arr[$i]->borderColor=='Disetujui'){
				$arr[$i]->borderColor='green';
			}else{ //status belum ditindaklanjuti
				$arr[$i]->borderColor='black';
			}
			// }elseif($arr[$i]->borderColor=='Ruang OK' || $arr[$i]->borderColor=='Ruang OK, undangan sedang dibuat'){
			// 	$arr[$i]->borderColor='red';
			// }elseif($arr[$i]->borderColor=='Undangan sudah dikirim'){
			// 	$arr[$i]->borderColor='red';
			// }elseif($arr[$i]->borderColor=='Selesai, menunggu notulen'){
			// 	$arr[$i]->borderColor='red';
			// }else{ //Selesai, notulen OK
			// 	$arr[$i]->borderColor='yellow';
			// }
		}
		$data = ['sesuatu' => $arr];
		$data['u'] = $this->input->get('update');
		$data['session'] = $this->session;
		// echo '<pre>';print_r($data['sesuatu']);die();
		$this->load->view('calendar',$data);
	}
	
  public function get_events(){
     // Our Start and End Dates
     $start = $this->input->get("start");
     $end = $this->input->get("end");

     $startdt = new DateTime('now'); // setup a local datetime
     $startdt->setTimestamp($start); // Set the date based on timestamp
     $start_format = $startdt->format('Y-m-d H:i:s');

     $enddt = new DateTime('now'); // setup a local datetime
     $enddt->setTimestamp($end); // Set the date based on timestamp
     $end_format = $enddt->format('Y-m-d H:i:s');

     $events = $this->calendar_model->get_events($start_format, $end_format);

     $data_events = array();

     foreach($events->result() as $r) {

         $data_events[] = array(
             "id" => $r->ID,
             "title" => $r->title,
             "description" => $r->description,
             "end" => $r->end,
             "start" => $r->start
         );
     }

     echo json_encode(array("events" => $data_events));
     exit();
 }

 public function add_event(){
    // Our calendar data 
    $name = $this->input->post("name", TRUE);
    $desc = $this->input->post("description", TRUE);
    $start_date = $this->input->post("start_date", TRUE);
    $end_date = $this->input->post("end_date", TRUE);

    if(!empty($start_date)) {
       $sd = DateTime::createFromFormat("Y/m/d H:i", $start_date);
       $start_date = $sd->format('Y-m-d H:i:s');
       $start_date_timestamp = $sd->getTimestamp();
    } else {
       $start_date = date("Y-m-d H:i:s", time());
       $start_date_timestamp = time();
    }

    if(!empty($end_date)) {
       $ed = DateTime::createFromFormat("Y/m/d H:i", $end_date);
       $end_date = $ed->format('Y-m-d H:i:s');
       $end_date_timestamp = $ed->getTimestamp();
    } else {
       $end_date = date("Y-m-d H:i:s", time());
       $end_date_timestamp = time();
    }

    $this->calendar_model->add_event(array(
       "title" => $name,
       "description" => $description,
       "start_date" => $start_date,
       "end_date" => $end_date
       )
    );
    redirect(site_url("calendar"));
	}

	public function updateEvent(){
    $param['id'] = $this->input->post('id');
    $param['start']=$this->input->post('start');
    $param['end']=$this->input->post('end');

    $r= $this->calendar_events->updateEvent($param);

    echo $r;
	}
	
	// public function viewPublic(){
	// 	$room  =""; //isset($this->input->get('r'))?$this->input->get('r'):'';
	// 	$user  =""; //isset($this->input->get('u'))?$this->input->get('u'):'';
	// 	$status=""; //isset($this->input->get('s'))?$this->input->get('s'):'';
	// 	
	// 	$this->load->model('Roomsmodel');
	// 	$title='';
	// 	if($this->input->get('r')!=''){
	// 		$room=$this->input->get('r');
	// 		$r =  $this->Roomsmodel->byId($room);
	// 		// echo '<pre>';print_r($r);die();
	// 		$title .= '<b style="font-size:30pt">&nbsp;'.$r->name.'</b>';
	// 	}
	// 	
	// 	$data = ['sesuatu' => $this->Calendarmodel->getAll($room,$user,$status),
	// 		'pageTitle'=>$title,
	// 		'extraCalendarSettings' => "minTime: '07:00:00', maxTime: '21:00:00', hiddenDays: [0,7]",
	// 		'calendarHeader'=>"left:'title',center:'',right:''"
	// 		//'calendarHeader'=>"left: 'prev,next today', center: 'title', right: 'month,agendaWeek,agendaDay'"
	// 		];
	// 	$this->load->view('calendar_public',$data);
	// }

}