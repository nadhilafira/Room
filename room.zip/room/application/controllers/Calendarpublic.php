<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendarpublic extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Calendarmodel');
		$this->load->model('Roomsmodel');
	}

	public function index() {
		// dayNow = date('N');
		
		
		$room  =""; //isset($this->input->get('r'))?$this->input->get('r'):'';
		$user  =""; //isset($this->input->get('u'))?$this->input->get('u'):'';
		$status=""; //isset($this->input->get('s'))?$this->input->get('s'):'';
		
		$title='Semua Ruangan';
		if($this->input->get('r')!=''){
			$room=$this->input->get('r');
			$r =  $this->Roomsmodel->byId($room);
			// echo '<pre>';print_r($r);die();
			$title = '<b style="font-size:30pt">&nbsp;'.$r->name.'</b>';
		}
		
		$data = ['sesuatu' => $this->Calendarmodel->getAll($room,$user,$status),
			'pageTitle'=>$title,
			'extraCalendarSettings' => "minTime: '07:00:00', maxTime: '21:00:00', hiddenDays: [0,6]",
			'calendarHeader'=>"left:'title',center:'',right:''"
			//'calendarHeader'=>"left: 'prev,next today', center: 'title', right: 'month,agendaWeek,agendaDay'"
			];
		$this->load->view('calendar_public',$data);
	}

}