<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct() {
		parent::__construct();
		if($this->session->userdata('login') !== true) redirect(base_url('login'));
		$this->load->model('Dashboardmodel');
		$this->load->model('Meetingsmodel');
	}

	public function index() {
		$output['session'] = $this->session;
		$output['title'] = 'Dashboard';
		
		// $x = $this->Meetingsmodel->getById(1);
		
		$output['data'] = $this->Dashboardmodel->getDashboardData();
		
		
		$this->load->view('dashboard',$output); //belum dibagi2 berdasarkan role
	}
}