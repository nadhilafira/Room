<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Meetings extends CI_CONTROLLER {
	// private $c = null;
	public function __construct() {
		parent::__construct();
		$this->load->library('grocery_CRUD');
		$this->load->model('Meetingsmodel');
		$this->load->model('Usersmodel');
		$this->load->helper('url');
		if($this->session->login !== true) redirect(base_url('login?ref='.urlencode(current_url().'?'.$_SERVER['QUERY_STRING'])));
	}
	public function index($op3='',$op4=''){
		if($op4!=''){
			if($this->session->role!='admin'){
				$u = $this->session->id;
				$r = $this->db->query("select id from meetings where id=$op4 and user=$u")->result();
				if(count($r)!=1){die('You cannot access this page');}
			}
		}
		
		$output['session'] = $this->session;
		$output['title'] = 'Meetings & Room Bookings';
		
		$c = new grocery_CRUD();
		$c->set_table('meetings');
		$c->display_as('no_undangan','No. surat undangan');
		$c->display_as('user','Peminjam');
		$c->display_as('tgl_undangan','Tgl. surat undangan');
		$c->callback_column('status',array($this,'_show_status_badge'));
		// $c->callback_column('participants',array($this,'_column_participant'));
		
		if($op3=='read'){
			$c->callback_read_field('participants',array($this,'_read_participants'));
			$c->callback_read_field('status',array($this,'_show_status_badge'));
			$c->set_read_fields('user', 'agenda', 'room', 'start', 'prev_meeting', 'participants', 'sumber_dana', 'status', 'created', 'modified');
			$c->display_as('start','Tanggal &amp; waktu');
			$c->callback_read_field('start',array($this,'_read_start'));
		}
		
		$output['scriptAfterJQuery']= '<script src="'.asset_url('plugins/select2/select2.full.min.js').'"></script><link rel="stylesheet" href="'.asset_url('plugins/select2/select2.min.css').'">'; //scripts to be loaded after jquery in HEAD
		
		// ======= daterangepicker when add and edit :START
		$output['scriptFooter']= "<script> $('#reservationtime').daterangepicker({";
		if($op3=='add'&&!isset($isPopup)){
			$output['scriptFooter'].= "autoUpdateInput: false,"; 
		}
		if($op3=='edit'){
			$x = $this->Meetingsmodel->getById($op4);
			$output['scriptFooter'].= "startDate: '".substr($x->start,0,16)."',endDate: '".substr($x->end,0,16)."',";
		}
		$output['scriptFooter'].= "timePicker: true,
				minDate: moment().startOf('day'),maxDate: moment().startOf('day').add(90,'day'),timePicker24Hour: true,timePickerIncrement: 15,locale: {format: 'YYYY-MM-DD HH:mm',cancelLabel: 'Clear'}
			});
		  $('#reservationtime').on('apply.daterangepicker', function(ev, picker) {
				$(this).val(picker.startDate.format('YYYY-MM-DD HH:mm') + ' - ' + picker.endDate.format('YYYY-MM-DD HH:mm'));
				$('#field-start').val(picker.startDate.format('YYYY-MM-DD HH:mm:ss'));
				$('#field-end').val(picker.endDate.format('YYYY-MM-DD HH:mm:ss'));
			});
			$('#reservationtime').on('cancel.daterangepicker', function(ev, picker) {
				$(this).val('');$('#field-start').val('');$('#field-end').val('');
			}); ";
		$output['scriptFooter'] .= "$('.participant_list').select2({
				minimumInputLength: 3, placeholder: 'Name or Email', tags: true,
				ajax: {
					url: '".base_url('users/byNameOrMail')."',dataType: 'json',delay:500,
					data: function(params) { return {search: params.term} },
					processResults: function (data, page) { return {results: data}; }
			}});";
		if($op3=='edit'){
			$output['scriptFooter'].= "
				$.ajax({
					type: 'GET',dataType: 'json',url: '".base_url('users/byMeeting?meeting='.$op4)."',
				}).then(function (data) {
					x=[];
					for(i=0;i<data.length;i++){
						var option = new Option(data[i].text, data[i].id, false, false);$('.participant_list').append(option).trigger('change');
						x[i]=data[i].id;
					}
					$('.participant_list').val(x);
					$('.participant_list').trigger('change'); 
				});
			$('#field-start').val( $('#reservationtime').val().split(' - ')[0]+':00' );
			$('#field-end').val( $('#reservationtime').val().split(' - ')[1]+':00' );
			";
		}
		if($op3=='edit'||$op3=='add'){
			$c->change_field_type('end','hidden');
		}
		// ======= daterangepicker when add and edit :END
		
		$c->display_as('prev_meeting','Previous meeting');
		// $c->field_type('participants','multiselect'); //kalo cuma ini, gabisa add orang diluar database
		$c->callback_before_insert(array($this,'_before_insert')); //encode participants[] dan set undangan based on template
		$c->callback_before_update(array($this,'_before_insert'));
		$c->callback_after_insert(array($this, '_after_insert')); //insert into table 'meeting_participants'
		$c->callback_after_update(array($this, '_after_insert'));
		$c->set_relation('room','rooms','name');
		$c->unset_edit_fields('no_undangan','tgl_undangan','minute_of_meeting','attachment','modified','created');
		// $c->field_hint('teks_undangan','<small><em>Teks untuk disertakan di surat undangan yang akan dibuat oleh DTE</em></small>');
		// $c->field_hint('prev_meeting','<small><em>Bila ada</em></small>');
		// $c->unset_delete();
		if($this->session->role == 'admin'){
			$c->display_as('attachment','Scan undangan');
			$c->callback_column('attachment',array($this,'_show_link_attachment'));
			$c->add_action('Cetak Undangan','','meetings/print_undangan','fa-print');
			$c->add_action('Upload Hasil Scan Undangan','','meetings/upload_undangan','fa-upload');
			// $c->add_action('Kirim Undangan','','meetings/send_undangan','fa-envelope');
			$c->unset_columns('prev_meeting','no_undangan','modified','teks_undangan','tgl_undangan','minute_of_meeting','status_note','participants');
			$c->unset_add_fields('no_undangan','tgl_undangan','attachment','modified','status_note');
			$c->set_relation('user','users','name');
			if($op3=='add'||$op3=='insert'){
				$c->field_type('status','hidden','Disetujui'); // $c->field_type('status','hidden','Ruang OK, undangan sedang dibuat'); //kalo dibikinin admin, statusnya otomatis OK
				$c->field_type('minute_of_meeting','hidden','<p> Ini adalah template. Silakan sesuaikan dengan kebutuhan Anda.</p> <p> Mohon hanya pilih peserta yang benar-benar hadir dari bagian <strong>Participants</strong> di atas.</p> <table border="1" cellpadding="3" cellspacing="0"> <thead> <tr> <th scope="col"> No.</th> <th scope="col"> Permasalahan dan PIC</th> <th scope="col"> Rekomendasi/Solusi dan Target Waktu</th> <th scope="col"> Status</th> </tr> </thead> <tbody> <tr> <td> 1</td> <td> contoh...</td> <td> contoh...</td> <td> contoh...</td> </tr> <tr> <td> 2</td> <td> contoh...</td> <td> contoh...</td> <td> &nbsp;</td> </tr> <tr> <td> 3</td> <td> tambahkan baris sesuai keperluan ...</td> <td> &nbsp;</td> <td> &nbsp;</td> </tr> </tbody> </table> <p> <strong>Lain-lain:</strong></p> <p> Contoh pembahasan lain-lain ...</p>');
				$c->field_type('teks_undangan','hidden');
			}elseif($op3=='edit'||$op3=='update'){
				$c->field_type('user','readonly');
				$c->field_type('agenda','readonly');
				// $c->field_type('teks_undangan','hidden');
				// $c->field_type('sumber_dana','readonly');
				// $c->field_type('prev_meeting','readonly');
				$output['scriptFooter'] .= "if($('#field-status').val()!='Ditolak'){
						$('#field-status_note').parent().parent().hide();
					}
					$('#field-participants').prop('disabled', true );
					$('#reservationtime').prop('disabled', true );
					$('#field-status').change(function(){
						if($('#field-status').val()=='Ditolak'){
							$('#field-status_note').parent().parent().show();
						}else{
							$('#field-status_note').parent().parent().hide(); 
						}
					});";
			}
			$c->required_fields('room','start','end');
		}elseif($this->session->role == 'dosen'){ //dosen
			// $c->add_action('Teks Undangan','','meetings/undangan/edit','fa-envelope');
			// $c->add_action('Participants','','meetings/participants/index','fa-user'); // $c->add_action('MoM','',array($this,'mom'),'fa-book');
			// $c->add_action('MoM &amp; Attendant','','meetings/mom/edit','fa-book'); // $c->add_action('MoM','',array($this,'mom'),'fa-book');
			// $c->unset_edit(); //kalo statusnya = 
			$c->unset_add_fields('no_undangan','tgl_undangan','attachment','modified','status','status_note');
			$c->unset_clone();
			$c->where('meetings.user',$this->session->id); //show only bookings made by this user
			if($op3=='add'||$op3=='insert'){
				$c->field_type('minute_of_meeting','hidden','<p> Ini adalah template. Silakan sesuaikan dengan kebutuhan Anda.</p> <p> Mohon hanya pilih peserta yang benar-benar hadir dari bagian <strong>Participants</strong> di atas.</p> <table border="1" cellpadding="3" cellspacing="0"> <thead> <tr> <th scope="col"> No.</th> <th scope="col"> Permasalahan dan PIC</th> <th scope="col"> Rekomendasi/Solusi dan Target Waktu</th> <th scope="col"> Status</th> </tr> </thead> <tbody> <tr> <td> 1</td> <td> contoh...</td> <td> contoh...</td> <td> contoh...</td> </tr> <tr> <td> 2</td> <td> contoh...</td> <td> contoh...</td> <td> &nbsp;</td> </tr> <tr> <td> 3</td> <td> tambahkan baris sesuai keperluan ...</td> <td> &nbsp;</td> <td> &nbsp;</td> </tr> </tbody> </table> <p> <strong>Lain-lain:</strong></p> <p> Contoh pembahasan lain-lain ...</p>');
				$c->field_type('teks_undangan','hidden');
			}elseif($op3=='edit'||$op3=='update'){
				$c->unset_fields('no_undangan','teks_undangan','minute_of_meeting','tgl_undangan','attachment','modified','status','status_note','created');
				$c->field_type('agenda','readonly');
				$c->field_type('room','readonly');
				$c->field_type('start','readonly');
				$c->display_as('start','Date &amp; time');
				$c->field_type('prev_meeting','readonly');
				$c->field_type('sumber_dana','readonly');
				$output['scriptFooter'] .= "$('#field-participants').prop('disabled', true );$('#reservationtime').prop('disabled', true );";
			}
			
			$c->columns('agenda','room','start','end','status','created');
			// $c->unset_texteditor('teks_undangan');
			// if already create booking: 
			// if booking approved: 
			// if already create undangan: unable edit beberapa field
			$c->field_type('user','hidden',$this->session->id);			
			$c->required_fields('user','room','start','end','agenda');
		}else{ //mahasiswa
			$output['title'] = 'Room Bookings';
			$c->unset_edit(); //kalo statusnya belum OK
			$c->unset_add_fields('no_undangan','tgl_undangan','minute_of_meeting','attachment','modified','status','status_note','sumber_dana','teks_undangan','prev_meeting');
			if($op3=='add'||$op3=='insert'){
				$c->field_type('minute_of_meeting','hidden','<p> Ini adalah template. Silakan sesuaikan dengan kebutuhan Anda.</p> <p> Mohon hanya pilih peserta yang benar-benar hadir dari bagian <strong>Participants</strong> di atas.</p> <table border="1" cellpadding="3" cellspacing="0"> <thead> <tr> <th scope="col"> No.</th> <th scope="col"> Permasalahan dan PIC</th> <th scope="col"> Rekomendasi/Solusi dan Target Waktu</th> <th scope="col"> Status</th> </tr> </thead> <tbody> <tr> <td> 1</td> <td> contoh...</td> <td> contoh...</td> <td> contoh...</td> </tr> <tr> <td> 2</td> <td> contoh...</td> <td> contoh...</td> <td> &nbsp;</td> </tr> <tr> <td> 3</td> <td> tambahkan baris sesuai keperluan ...</td> <td> &nbsp;</td> <td> &nbsp;</td> </tr> </tbody> </table> <p> <strong>Lain-lain:</strong></p> <p> Contoh pembahasan lain-lain ...</p>');
			}
			$c->where('meetings.user',$this->session->id); //show only bookings made by this user
			$c->unset_columns('user','teks_undangan','tgl_undangan','minute_of_meeting','attachment','status_note','prev_meeting','no_undangan','sumber_dana','participants');
			$c->field_type('user','hidden',$this->session->id);
			$c->required_fields('user','room','start','end','agenda');
		}
		$c->set_relation('prev_meeting','meetings','{agenda} -- {start}');		
		if($op3=='add'){
			$c->field_type('created','hidden',date('Y-m-d H:i:s'));
			$c->display_as('start','Date &amp; Time');
		}
		
		// tambahin field buat di add & edit: participants, dan bikin callback agar manggil select2.js
		$c->callback_add_field( 'participants',array($this,'_add_edit_field_participants'));
		$c->callback_edit_field('participants',array($this,'_add_edit_field_participants'));
		// info: we will send invitation email to this participants if the budget & room bookings are approved (di sisi admin, saat update, bila status jadi approved, blast email)
		// callback before update & before insert utk nge-save ke tabel meeting_participants
		
		$c->callback_add_field('start',array($this,'_add_edit_field_start'));
		$c->callback_edit_field('start',array($this,'_add_edit_field_start'));
		
		$output['scriptFooter'] .= "</script>";
		$output['output'] = $c->render();
		// $this->c = $c;

		$this->load->view('common_crud',$output);
	}
	public function pop($op3='',$op4=''){
		if($op3=='edit'){
			if($this->session->role!='admin'){
				$u = $this->session->id;
				$r = $this->db->query("select id from meetings where id=$op4 and user=$u")->result();
				if(count($r)!=1){die('You cannot access this page');}
			}
		}
		$isModal = $this->input->get('m');
		$isPopup = $this->input->get('w');
		$output['session'] = $this->session;
		$c = new grocery_CRUD();
		$c->set_table('meetings');
		$c->unset_list()->unset_delete()->unset_clone()->unset_read();
		$c->display_as('no_undangan','No. surat undangan');
		$c->display_as('user','Peminjam');
		$c->display_as('tgl_undangan','Tgl. surat undangan');
		$c->callback_read_field('participants',array($this,'_read_participants'));
		$c->callback_read_field('status',array($this,'_show_status_badge'));
		// $c->callback_column('status',array($this,'_show_status_badge')); //unset 
		
		// $output['scriptBeforeJQuery']= ; //scripts to be loaded before jquery
		$output['scriptAfterJQuery']= '<script src="'.asset_url('plugins/select2/select2.full.min.js').'"></script><link rel="stylesheet" href="'.asset_url('plugins/select2/select2.min.css').'">'; //scripts to be loaded after jquery
		$output['scriptFooter']= "<script> $('#reservationtime').daterangepicker({";
		if($op3=='add'&&!isset($isPopup)){ $output['scriptFooter'].= "autoUpdateInput: false,"; }
		if($op3=='edit'){
			$x = $this->Meetingsmodel->getById($op4);
			$output['scriptFooter'].= "startDate: '".substr($x->start,0,16)."',endDate: '".substr($x->end,0,16)."',"; //if edit
		}
		if(isset($isPopup)){
			$a = urldecode($this->input->get('dayStart'));
			$b = urldecode($this->input->get('dayEnd')); //2019-09-19 12:30
			$this->session->set_userdata('updatedDate',$a);
			if($a!=''&&$b!=''){
				if(substr($a,11)=='00:00' && substr($b,11)=='00:00'){
					$a = date('Y-m-d', strtotime('-0 day', strtotime(substr($a,0,10)))).' 11:00';
					$b = date('Y-m-d', strtotime('-1 day', strtotime(substr($b,0,10)))).' 12:00';
				}
				$output['scriptFooter'].= "startDate: '$a',endDate: '$b',";
			}
			$c->unset_back_to_list();
		}
		$c->set_lang_string('insert_success_message',"Done. Now going back...<script type='text/javascript'>window.opener.location.href='".base_url('calendar?update='.$this->session->updatedDate)."';window.close()</script>");
		$c->set_lang_string('update_success_message',"Done. Now going back...<script type='text/javascript'>window.opener.location.href='".base_url('calendar?update='.$this->session->updatedDate)."';window.close()</script>");
		$output['scriptFooter'].= "timePicker: true,
																minDate: moment().startOf('day'),maxDate: moment().startOf('day').add(90,'day'),timePicker24Hour: true,timePickerIncrement: 15,locale: {format: 'YYYY-MM-DD HH:mm',cancelLabel: 'Clear'}
															});
															$('#reservationtime').on('apply.daterangepicker', function(ev, picker) {
																$(this).val(picker.startDate.format('YYYY-MM-DD HH:mm') + ' - ' + picker.endDate.format('YYYY-MM-DD HH:mm'));
																$('#field-start').val(picker.startDate.format('YYYY-MM-DD HH:mm:ss'));
																$('#field-end').val(picker.endDate.format('YYYY-MM-DD HH:mm:ss'));
															});
															$('#reservationtime').on('cancel.daterangepicker', function(ev, picker) {
																$(this).val('');$('#field-start').val('');$('#field-end').val('');
															}); ";
		$output['scriptFooter'] .= "$('.participant_list').select2({
															minimumInputLength: 3, placeholder: 'Name or Email', tags: true,
															ajax: {
																url: '".base_url('users/byNameOrMail')."',dataType: 'json',delay:500,
																data: function(params) { return {search: params.term} },
																processResults: function (data, page) { return {results: data}; }
														}});";
		if($op3=='edit'){
			$output['scriptFooter'].= "
														$.ajax({
															type: 'GET',dataType: 'json',url: '".base_url('users/byMeeting?meeting='.$op4)."',
														}).then(function (data) {
															x=[];
															for(i=0;i<data.length;i++){
																var option = new Option(data[i].text, data[i].id, false, false);$('.participant_list').append(option).trigger('change');
																x[i]=data[i].id;
															}
															$('.participant_list').val(x);
															$('.participant_list').trigger('change'); 
														});
													$('#field-start').val( $('#reservationtime').val().split(' - ')[0]+':00' );
													$('#field-end').val( $('#reservationtime').val().split(' - ')[1]+':00' );
													";
		}
		if(isset($isPopup)){
			$output['scriptFooter'].= "
														$('#field-start').val( $('#reservationtime').val().split(' - ')[0]+':00' );
														$('#field-end').val( $('#reservationtime').val().split(' - ')[1]+':00' ); ";
		}
		
		$c->display_as('prev_meeting','Previous meeting');
		$c->change_field_type('end','hidden');
		$c->callback_before_insert(array($this,'_before_insert'));
		$c->callback_before_update(array($this,'_before_insert'));
		$c->callback_after_insert (array($this,'_after_insert' ));
		$c->callback_after_update (array($this,'_after_insert' ));
		$c->set_relation('room','rooms','name');
		$c->unset_edit_fields('no_undangan','tgl_undangan','minute_of_meeting','attachment','modified','created');
		
		if($this->session->role == 'admin'){
			$output['title'] = 'Meetings & Room Bookings';
			$c->unset_columns('teks_undangan','tgl_undangan','minute_of_meeting','attachment','status_note','participants');
			$c->unset_add_fields('no_undangan','tgl_undangan','attachment','modified','status_note');
			$c->set_relation('user','users','name');
			if($op3=='add'||$op3=='insert'){
				// $c->field_type('status','hidden','Ruang OK, undangan sedang dibuat'); //kalo dibikinin admin, statusnya otomatis OK
				$c->field_type('status','hidden','Disetujui'); //kalo dibikinin admin, statusnya otomatis OK
			}
			if($op3=='edit'||$op3=='update'){
				$c->field_type('user','readonly');
				$c->field_type('agenda','readonly');
				// $c->field_type('teks_undangan','readonly');
				$c->field_type('sumber_dana','readonly');
				// $c->unset_texteditor('teks_undangan');
				$c->field_type('prev_meeting','readonly');
				$output['scriptFooter'] .= "if($('#field-status').val()!='Ditolak'){
																			$('#field-status_note').parent().parent().hide();
																		}
																		$('#field-participants').prop('disabled', true );
																		$('#reservationtime').prop('disabled', true );
																		$('#field-status').change(function(){
																			if($('#field-status').val()=='Ditolak'){
																				$('#field-status_note').parent().parent().show();
																			}else{
																				$('#field-status_note').parent().parent().hide(); 
																			}
																		});";
				// kalo statusnya udah
			}
			$c->required_fields('room','start','end');
			$c->set_relation('prev_meeting','meetings','{agenda} -- {start}');		
		}
		elseif($this->session->role == 'dosen'){ //dosen
			$output['title'] = 'Meetings';
			$c->unset_add_fields('no_undangan','tgl_undangan','attachment','modified','status','status_note');;
			$c->unset_fields('no_undangan','tgl_undangan','attachment','minute_of_meeting','modified','status_note','sumber_dana','created','teks_undangan');
			if($op3=='add'){
				$c->unset_fields('no_undangan','tgl_undangan','attachment','minute_of_meeting','modified','status_note','sumber_dana','created','teks_undangan','status');
			}
			$c->where('meetings.user',$this->session->id); //show only bookings made by this user
			$c->columns('agenda','room','start','end','status','created');
			$c->field_type('user','hidden',$this->session->id);			
			$c->required_fields('user','room','start','end','agenda');
			$c->set_relation('prev_meeting','meetings','{agenda} -- {start}',array('user' => $this->session->id));
			$c->field_type('status','readonly');
		}else{ //mahasiswa
			redirect('logout');
			$output['title'] = 'Room Bookings';
			$c->unset_edit(); //kalo statusnya belum OK
			$c->unset_add_fields('no_undangan','tgl_undangan','attachment','modified','status','status_note','sumber_dana','prev_meeting');;
			$c->where('meetings.user',$this->session->id); //show only bookings made by this user
			$c->unset_columns('user','teks_undangan','tgl_undangan','minute_of_meeting','attachment','status_note','prev_meeting','no_undangan','sumber_dana','participants');
			$c->field_type('user','hidden',$this->session->id);
			$c->required_fields('user','room','start','end','agenda');
			$c->set_relation('prev_meeting','meetings','{agenda} -- {start}',array('user' => $this->session->id));
		}
		if($op3=='add'){
			$c->field_type('created','hidden',date('Y-m-d H:i:s'));
			$c->display_as('start','Date &amp; Time');
			$c->field_type('teks_undangan','hidden');
			$c->field_type('minute_of_meeting','hidden','<p> Ini adalah template. Silakan sesuaikan dengan kebutuhan Anda.</p> <p> Mohon hanya pilih peserta yang benar-benar hadir dari bagian <strong>Participants</strong> di atas.</p> <table border="1" cellpadding="3" cellspacing="0"> <thead> <tr> <th scope="col"> No.</th> <th scope="col"> Permasalahan dan PIC</th> <th scope="col"> Rekomendasi/Solusi dan Target Waktu</th> <th scope="col"> Status</th> </tr> </thead> <tbody> <tr> <td> 1</td> <td> contoh...</td> <td> contoh...</td> <td> contoh...</td> </tr> <tr> <td> 2</td> <td> contoh...</td> <td> contoh...</td> <td> &nbsp;</td> </tr> <tr> <td> 3</td> <td> tambahkan baris sesuai keperluan ...</td> <td> &nbsp;</td> <td> &nbsp;</td> </tr> </tbody> </table> <p> <strong>Lain-lain:</strong></p> <p> Contoh pembahasan lain-lain ...</p>');
		}
		
		// tambahin field buat di add & edit: participants, dan bikin callback agar manggil select2.js
		$c->callback_add_field( 'participants',array($this,'_add_edit_field_participants'));
		$c->callback_edit_field('participants',array($this,'_add_edit_field_participants'));
		// info: we will send invitation email to this participants if the budget & room bookings are approved (di sisi admin, saat update, bila status jadi approved, blast email)
		// callback before update & before insert utk nge-save ke tabel meeting_participants
		
		$c->callback_add_field('start',array($this,'_add_edit_field_start'));
		$c->callback_edit_field('start',array($this,'_add_edit_field_start'));
		
		if(isset($isPopup)){
			// $output['scriptFooter'].= "window.onbeforeunload = function(){window.opener.location.reload();}";
		}
		
		$output['scriptFooter'] .= "</script>";
		$output['output'] = $c->render();
		// $this->c = $c;

		if(isset($isModal)){
			$this->load->view('common_modal',$output);
		}elseif(isset($isPopup)){
			$this->load->view('common_blank',$output);
		}else{
			$this->load->view('common_crud',$output);
		}
	}
	public function mom($primary_key, $row){ //kasih pengaman: auto redirect ke edit, hanya bisa oleh dosen & pegawai
		//?
		//tambahi kolom attendant, copy conten dari participants, pakein select2 no tag no ajax
		//$c->callback_read_field('participants',function($value, $pKey){return $value}); //display as <ol.. li>
		
		
		$c = new grocery_CRUD();
		$output['session'] = $this->session;
		$output['title'] = 'Minutes of Meeting';
		$c->set_table('meetings')
			->where('id',$primary_key)
			->unset_list()
			->unset_read()
			->unset_delete()
			->unset_edit_fields('user','end','prev_meeting','no_undangan','tgl_undangan','teks_undangan','status_note','created','modified')
			->required_fields('minute_of_meeting')
			->field_type('agenda','readonly')
			->field_type('room','readonly')
			->field_type('start','readonly')
			->field_type('sumber_dana','readonly')
			->field_type('status','readonly')
			->display_as('start','Tanggal &amp; Waktu Meeting')
			->set_relation('room','rooms','name')
			->set_field_upload('attachment','assets/uploads/meetings_attachment')
			->unset_back_to_list();
		$c->set_lang_string('update_success_message',
		 'Updated. Now redirecting to the list...
		 <script type="text/javascript">window.location = "'.site_url(strtolower(__CLASS__)).'";</script>
		 <div style="display:none">'
		);
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function undangan($primary_key, $row){ //kasih pengaman: auto redirect ke edit, hanya bisa oleh dosen & pegawai
		$c = new grocery_CRUD();
		$output['session'] = $this->session;
		$output['title'] = 'Undangan';
		$c->set_table('meetings')
			->where('id',$primary_key)
			->unset_list()
			->unset_read()
			->unset_delete()
			->unset_edit_fields('user','end','prev_meeting','attachment','status_note','created','modified','minute_of_meeting')
			->required_fields('no_undangan','tgl_undangan','teks_undangan')
			->field_type('agenda','readonly')
			->field_type('room','readonly')
			->field_type('start','readonly')
			->field_type('sumber_dana','readonly')
			->field_type('status','readonly')
			->display_as('start','Tanggal &amp; Waktu Meeting')
			->set_relation('room','rooms','name')
			->unset_back_to_list();
		$c->set_lang_string('update_success_message',
		 'Updated. Now redirecting to the list...
		 <script type="text/javascript">window.location = "'.site_url(strtolower(__CLASS__)).'";</script>
		 <div style="display:none">'
		);
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function participants(){
		// die($this->uri->segment(3).'-'.$this->uri->segment(4).'-'.$this->uri->segment(5));
		$op3='';$op3=$this->uri->segment(3); //must be: index/id_meeting, add, delete, view, 
		$op4='';$op4=$this->uri->segment(4);
		if($op3=='' || ($op3=='index' && $op4=='')){redirect(base_url('meetings'));}
		
		$c = new grocery_CRUD();
		$output['session'] = $this->session;
		$output['title'] = 'Participants';
		$c->set_table('meeting_participants')
			->where('meeting',$op4);
			
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function list_undangan_disabled(){
		$c = new grocery_CRUD();
		$output['session'] = $this->session;
		$output['title'] = 'Undangan';
		$c->set_table('meetings')
			->unset_delete()
			->where('no_undangan !=','')
			->required_fields('no_undangan','tgl_undangan','teks_undangan')
			->unset_edit_fields('user','end','prev_meeting','attachment','status_note','created','modified','minute_of_meeting')
			->field_type('agenda','readonly')
			->field_type('room','readonly')
			->field_type('start','readonly')
			->field_type('sumber_dana','readonly')
			->field_type('status','readonly')
			->display_as('start','Tanggal &amp; Waktu Meeting')
			->set_relation('room','rooms','name')
			->set_relation('user','users','name')
			->columns('agenda','room','start','no_undangan','tgl_undangan','sumber_dana','status');
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function list_mom($o='',$i=''){
		$c = new grocery_CRUD();
		$output['session'] = $this->session;
		$output['title'] = 'Minutes of Meeting';
		$c->set_table('meetings')
			->unset_delete()
			->unset_read()
			->required_fields('minute_of_meeting')
			->fields('agenda','room','start','attendee','minute_of_meeting') // ->unset_edit_fields('user','end','prev_meeting','no_undangan','tgl_undangan','teks_undangan','status_note','created','modified')
			->unset_clone()
			->display_as('attendee','Attendee*')
			->field_type('agenda','readonly')
			->field_type('room','readonly')
			->field_type('start','readonly')
			->field_type('sumber_dana','readonly')
			->field_type('status','readonly')
			->display_as('start','Date &amp; time')
			->set_relation('room','rooms','name')
			->set_relation('user','users','name')
			->callback_edit_field('attendee',array($this,'_edit_field_attendee'))
			->callback_before_update(array($this, '_before_update_mom'))
			->columns('agenda','room','start','sumber_dana')
			->set_field_upload('attachment','assets/uploads/meetings_attachment');
		if($this->session->role=='admin'){
			$c->where(array('meetings.status' => 'Disetujui', 'minute_of_meeting !=' => ''));
		}else{
			$c->where(array('meetings.status' => 'Disetujui', 'minute_of_meeting !=' => '', 'user' => $this->session->id));
		}
		if($o=='edit'){
			$output['scriptAfterJQuery']= '<script src="'.asset_url('plugins/select2/select2.full.min.js').'"></script><link rel="stylesheet" href="'.asset_url('plugins/select2/select2.min.css').'">'; //scripts to be loaded after jquery
			$output['scriptFooter']= "<script>
				$('.participant_list').select2({
				minimumInputLength: 3, placeholder: 'Name or Email', tags: true,
				ajax: {
					url: '".base_url('users/byNameOrMail')."',dataType: 'json',delay:500,
					data: function(params) { return {search: params.term} },
					processResults: function (data, page) { return {results: data}; }
				}});
				$.ajax({
					type: 'GET',dataType: 'json',url: '".base_url('users/byMeeting?meeting='.$i)."',
				}).then(function (data) {
					x=[];
					for(i=0;i<data.length;i++){
						var option = new Option(data[i].text, data[i].id, false, false);$('.participant_list').append(option).trigger('change');
						x[i]=data[i].id;
					}
					$('.participant_list').val(x);
					$('.participant_list').trigger('change'); 
				});
			</script>";
		}
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	function _edit_field_attendee($v,$i){
		$t = "<select name='attendee[]' multiple style='width:300px;height:150px'>";
		$u = $this->Usersmodel->byMeeting2($i);
		foreach($u as $usr){
			$s = '';
			if($usr->status==1){$s = 'selected="selected"';}
			$t.='<option value="'.$usr->id.'" '.$s.'>'.$usr->name.' ('.$usr->email.')</option>';
		}
		$t .= "</select><br><small>Use CTRL+Click to select multiple names who really atttend the meeting.</small>
		";
		return $t;
	}
	function _add_edit_field_start(){
		return '<input type="text" class="form-control active" id="reservationtime"><input id="field-start" type="hidden" name="start" value="">';
	}
	function _add_edit_field_participants(){
		return '
		<select id="field-participants" class="participant_list" name="participants[]" multiple="multiple" style="width:50%">
		</select>
		<br><small>Invitation is sent to participants if the budget and room bookings are approved.</small>';
	}
	function _before_insert($post_array){
		if(isset($post_array['participants'])){
			$post_array['participants'] = json_encode($post_array['participants']);
		}else{
			unset($post_array['participants']);
		}
		if($post_array['teks_undangan']==''){
			if($post_array['sumber_dana']=='Ventura'||$post_array['sumber_dana']=='DTE'){ // undangan diset hanya bila sumber dana adalah DTE atau ventura
				$fromTemplate = '';
				require(__DIR__ . '\..\views\surat\undangan.php');
				$post_array['teks_undangan'] = $fromTemplate;
			}
		}
		return $post_array;
	}
	function _after_insert($post_array,$primary_key){
		$this->Meetingsmodel->cleanAndInsertParticipants($primary_key,$post_array['participants']);
		return true;
	}
	function _read_start($val, $pKey){
		$r = $this->db->query("select end from meetings where id=$pKey")->row();
		return $val.' - '.$r->end;
	}
	function _read_participants($val, $pKey){
		$t = '';
		if($val!=''){
			$val = str_replace('[','',$val);
			$val = str_replace(']','',$val);
			$ar = explode(',',$val);
			if(count($ar)>0){
				$t .= '<ol>';
				foreach ($ar as $v){
					$v = str_replace('"','',$v);
					if(is_numeric($v)){
						$u = $this->Usersmodel->byId($v);
						if(!is_null($u)){
							$v = $u->name;
						}
					}
					$t .= '<li>'.$v.'</li>';
				}
				$t .= '</ol>';
			}
		}
		return $t;
	}
	// function _column_participant($val, $pKey){
	// 	$t = '';
	// 	if($val!=''){
	// 		$val = str_replace('[','',$val);
	// 		$val = str_replace(']','',$val);
	// 		$ar = explode(',',$val);
	// 		if(count($ar)>0){
	// 			foreach ($ar as $v){
	// 				$v = str_replace('"','',$v);
	// 				if(is_numeric($v)){
	// 					$u = $this->Usersmodel->byId($v);
	// 					if(!is_null($u)){
	// 						$v = $u->name;
	// 					}
	// 				}
	// 				$t .= $v.', ';
	// 			}
	// 		}
	// 		$t = rtrim($t,', ');
	// 	}
	// 	return $t;
	// }
	function _show_link_attachment($val,$row){
		return '<a href="'.base_url().'/assets/uploads/meetings_attachment/'.$val.'">'.$val.'</a>';
	}
	function _show_status_badge($val,$row){
		switch($val){
			case 'Menanti pengecekan':
				$c= '#f2bb79';break;
			case 'Ditolak':
				$c= '#ff0000';break;
			case 'Disetujui':
				$c= '#bacc4b';break;
			// case 'Ruang OK':
			// 	$c= '#bacc4b';break;
			// case 'Ruang OK, undangan sedang dibuat':
			// 	$c= '#bacc4b';break;
			// case 'Undangan sudah dikirim':
			// 	$c= '#7ccc4b';break;
			// case 'Selesai':
			// 	$c= '#4ba5cc';break;
			// case 'menunggu notulen':
			// 	$c= '#4bcca5';break;
			// case 'notulen OK':
			// 	$c= '#4ba5cc';break;
			default:
				$c= '';
		}
		if(is_numeric($row)){
			$status_note = $this->db->query("select status_note from meetings where id=$row")->row()->status_note;
			return '<span style="font-size:smaller;font-weight:bold;color:'.$c.'">'.$val.'</span> '.$status_note;
		}else{
			return '<span style="font-size:smaller;font-weight:bold;color:'.$c.'">'.$val.'</span> '.$row->status_note;
		}
	}
	// function _redirect_to_calendar($post_array,$primary_key){
	// 	$data = "Done. Now going back...<script type='text/javascript'>window.opener.location.reload();window.close()</script>";
	// 	$this->c->set_lang_string('insert_success_message', $data);
	// 	return $post;
	// }
	function reschedule(){
		$response = array();
		$param = $this->input->post();
		$calendar_id = $param['id'];
		
		if($this->session->role!='admin'){
			$u = $this->session->id;
			$r = $this->db->query("select id from meetings where id=$calendar_id and user=$u")->result();
			if(count($r)!=1){
				$response['status'] = FALSE;
				$response['notif']	= 'Updated data does not exist';
				die(json_encode($response));
			}
		}
		
		$cnt = $this->db->where('id',$calendar_id)->count_all_results('meetings');
		if($cnt == 1){
			unset($param['id']);
			$param['modified'] = date('Y-m-d H:i:s');
			$this->db->update('meetings',$param,'id='.$calendar_id);
			$update = $this->db->affected_rows();
			if ($update > 0) {
				$response['status'] = TRUE;
				$response['notif']	= 'Success add calendar';
				$response['id']		= $calendar_id;
			}else{
				$response['status'] = FALSE;
				$response['notif']	= 'Cannot update';
			}
		}else{
			$response['status'] = FALSE;
			$response['notif']	= 'Updated data does not exist';
		}
		echo json_encode($response);
	}
	function _before_update_mom($post_array,$primary_key){
		// echo '<pre>';print_r($post_array['attendee']);die();
		$this->db->query("update meeting_participants set status = 1 where id in (".implode(',',$post_array['attendee']).")");
		unset($post_array['attendee']);
		return $post_array;
		
		// foreach($post_array['attendee'] as $u){
		// 	$u
		// }
		// $this->db->update_batch('meeting_participants',$data,'id');
	}
	function dropAndDelete($id){
		$response['status'] = FALSE;
		if($this->session->role == 'admin'){
			$cnt = $this->db->query("select id from meetings where id=$id")->result();
			if(count($cnt) == 1){
				$this->db->where('meeting',$id)->delete('meeting_participants');
				$res = $this->db->where('id',$id)->delete('meetings');
				if($res!=false){
					$response['status'] = TRUE;
				}
			}
		}else{
			$u = $this->session->id;
			$r = $this->db->query("select id from meetings where id=$id and user=$u")->result();
			if(count($r)!=1){
				die(json_encode($response));
			}else{
				$this->db->where('meeting',$id)->delete('meeting_participants');
				$res = $this->db->where('id',$id)->delete('meetings');
				if($res!=false){
					$response['status'] = TRUE;
				}
			}
		}
		echo json_encode($response);
	}
	function upload_undangan($id,$o=''){
		if($this->session->role!='admin'){redirect('dashboard');}
		if(in_array($o,array('','index','add','read','insert','delete','clone'))){redirect('meetings/upload_undangan/'.$id.'/edit/'.$id);}
		if($o=='success'){redirect('meetings');}
		$output['title'] = 'Upload Hasil Scan Undangan';
		$c = new grocery_CRUD();
		$c->set_table('meetings')
			->edit_fields('agenda','room','start','attachment')
			->display_as('start','Date &amp; time')
			->display_as('attachment','Hasil scan undangan')
			->set_field_upload('attachment','assets/uploads/meetings_attachment')
			->set_relation('room','rooms','name')
			->field_type('agenda','readonly')
			->field_type('room','readonly')
			->field_type('start','readonly')
			// ->set_lang_string('update_success_message',"Done. Now going back...<script type='text/javascript'>window.location.href='".base_url('meetings')."'</script>")
			->set_lang_string('update_success_message',"Done. Now sending the invitation...<script type='text/javascript'>window.location.href='".base_url('meetings/send_undangan/'.$id)."'</script>")
			->unset_back_to_list();
		
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	function print_undangan($id){
		$r = $this->db->query("select * from meetings where id=$id")->row();
		if($r->status != 'Disetujui'){$this->session->set_flashdata('error','Status peminjaman belum disetujui.');redirect('meetings/index/edit/'.$id);}
		$r2 = $this->db->query("select * from meeting_participants where meeting=$id")->result();
		if(count($r2) < 1){$this->session->set_flashdata('warning','No Participant.');redirect('meetings/index/edit/'.$id);}
		
		$output['body'] = $r->teks_undangan;
		$this->load->view('common_surat',$output);
	}
	function send_undangan($id){
		// die('Cannot connect to mail server.');
		if($this->session->role!='admin'){redirect('dashboard');}
		
		$r = $this->db->query("select * from meetings where id=$id")->row();
		if(empty($r->participants)){ die("No participants.<br>Redirecting back...<script type='text/javascript'>setTimeout(function(){ window.location.href='".base_url('meetings')."'; },3000);</script>"); } //no participants
		if($r->teks_undangan ==''){ die("No text to send.<br>Redirecting back...<script type='text/javascript'>setTimeout(function(){ window.location.href='".base_url('meetings')."'; },3000);</script>"); } //no teks_undangan
		$to = array();
		$tmp1 = explode(',',$r->participants);
		
		for($i=0;$i<count($tmp1);$i++){
			$p = trim($tmp1[$i],']["');
			if(is_numeric($p)){
				$tmp = $this->db->query("select email from users where id=$p")->row();
				if(!empty($tmp)){
					array_push($to,strtolower($tmp->email));
				}
			}else{
				if($this->checkEmail($p)){
					array_push($to,strtolower($p));
				}
			}
		}
		if(empty($to)){ die("No valid email for participants.<br>Redirecting back...<script type='text/javascript'>setTimeout(function(){ window.location.href='".base_url('meetings')."'; },3000);</script>"); } //no valid emails
		
		// require(__DIR__ . '\..\views\surat\undangan.php');
		// require('_sendMail.php');
		
		$this->load->library('email');
		// $config['protocol'] = 'sendmail';
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		
		$this->email->from('noreply.doffice@ee.ui.ac.id', 'D-Office Bot');
		$this->email->to($to);
		$this->email->bcc('d-office.dump@ruki.web.id');
		$this->email->subject('[D-Office] Undangan '.$r->agenda);
		$this->email->message($r->teks_undangan);
		$this->email->attach(asset_url('uploads/meetings_attachment/'.$r->attachment));
		if($this->email->send()){
			die("Email sent.<br>Redirecting back...<script type='text/javascript'>setTimeout(function(){ window.location.href='".base_url('meetings')."'; },1000);</script>");
		}else{
			die("Error. Cannot send email invitation.<br>Redirecting back...<script type='text/javascript'>setTimeout(function(){ window.location.href='".base_url('meetings')."'; },3000);</script>");
		}
		
	}
	private function checkEmail($email) {
		 $find1 = strpos($email, '@');
		 $find2 = strpos($email, '.');
		 return ($find1 !== false && $find2 !== false && $find2 > $find1);
	}
}