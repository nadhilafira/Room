<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rooms extends CI_CONTROLLER {
	public function __construct() {
		parent::__construct();
		$this->load->library('grocery_CRUD');
		$this->load->model('Roomsmodel');
		if($this->session->role != 'admin') redirect(base_url('bookings'));
		if($this->session->login !== true) redirect(base_url('login'));
	}

	public function index(){
		$c = new grocery_CRUD();
		$output['title'] = 'Rooms';
		$output['session'] = $this->session;
		$c->set_table('rooms')
			->callback_column('color',array($this,'_callback_column_color'))
			->callback_edit_field('color',array($this,'_callback_edit_color') )
			->callback_add_field('color',array($this,'_callback_edit_color') )
			->callback_read_field('color',array($this,'_callback_column_color'))
			->field_type('capacity','integer')
			->field_type('facility','multiselect',array(
				'Projector'=>'Projector',
				'TV'=>'TV',
				'AC'=>'AC',
				'Mic'=>'Mic',
				'Teleconference'=>'Teleconference',
				'Dispenser'=>'Dispenser',
				'Multi-mode ambient lighting'=>'Multi-mode ambient lighting',
				'Sofa'=>'Sofa',
				'Whiteboard'=>'Whiteboard',
				'Podium'=>'Podium',
				));
				
		$op3='';$op3=$this->uri->segment(3);
		if($op3=='edit'||$op3=='add'){
			$output['scriptBeforeJQuery'] = '<link rel="stylesheet" href="'.asset_url('plugins/colorpicker/bootstrap-colorpicker.min.css').'">';
			// $output['scriptAfterJQuery'] = '';
			$output['scriptFooter'] = '<script src="'.asset_url('plugins/colorpicker/bootstrap-colorpicker.min.js').'"></script><script>$(".my-colorpicker2").colorpicker()</script>';
			// $output['scriptToExecuteAtBodyEnd'] = "";
		}
			
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	
	public function getJson(){
		die(json_encode($this->Roomsmodel->getAll()));
	}
	
	function _callback_column_color($value, $row){
		return '<div style="width:20px;border-radius:20px;height:20px;background:'.$value.';display:inline-block;vertical-align:bottom;"></div>&nbsp;'.$value;
	}
	function _callback_edit_color($value, $row){
		$value = $value == '' ? '#d49941' : $value;
		return '<div class="input-group my-colorpicker2 colorpicker-element">
							<div class="input-group-addon"><i style="background-color: '.$value.';border-radius:10px"></i></div>
							<input type="text" name="color" id="field-color" class="form-control" value="'.$value.'">
						</div>';
	}
	
}