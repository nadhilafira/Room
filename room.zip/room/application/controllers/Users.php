<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_CONTROLLER {
	public function __construct() {
		parent::__construct();
		$this->load->library('grocery_CRUD');
		if($this->session->login !== true) redirect(base_url('login'));
		$this->load->model('Usersmodel');
	}
	public function index() {
		$c = new grocery_CRUD();
		$output['title'] = 'Users';
		$output['session'] = $this->session;
		$c->set_table('users');
		$c->unset_columns('password');
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function dosen() {
		$c = new grocery_CRUD();
		$output['title'] = 'Dosen';
		$output['session'] = $this->session;
		$c->set_table('users')->where('role','dosen');
		$c->unset_columns('password');
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
	public function staff() {
		$c = new grocery_CRUD();
		$output['title'] = 'Dosen';
		$output['session'] = $this->session;
		$c->set_table('users')->where('role','staff');
		$c->unset_columns('password');
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}	
	
	
	
	
	public function edit($id) {
		$data = ['user' => $this->usersmodel->byId($id)];
		$this->load->view('users_edit', $data);
	}

	public function doedit($id) {
		$data = [
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email')
		];

		$password = $this->input->post('password');
		if($password){
			$data['password'] = md5($password);
		}

		if($password && ($password !== $this->input->post('password_confirm'))) {
			echo json_encode(['success' => false, 'data' => 'Password not match']);
			exit();
		}

		$doedit = $this->usersmodel->update($data, $id);
		if($doedit) {
			echo json_encode(['success' => true]);
		}else{
			echo json_encode(['success' => false, 'data' => 'User updated failed']);
		}
	}

	public function create() {
		$this->load->view('users_create');
	}

	public function delete($id) {
		$this->usersmodel->delete($id);
		$this->session->set_flashdata('msg', 'User deleted successfully.');
		redirect(base_url('users'));
	}
	
	// menampilkan halaman edit profile utk tiap user yg login
	public function profile($o='',$u=''){
		// if($o!=''||$u!=''||($o=='edit'&& $u!=$this->session->id)){
		// 	redirect('dashboard');
		// }
		$c = new grocery_CRUD();
		$output['title'] = 'Your Profile';
		$output['session'] = $this->session;
		$c->set_table('users');
    $c->callback_before_update(array($this,'_encryptPassword'));
		if($o=='edit'){
			$c->callback_edit_field('password',function ($v, $pk) {
        return '<input id="field-password" class="form-control" type="password" name="password"><small><em>leave it blank to use the current password</em></small>';
			});
		}
    $c->unset_back_to_list();
		$c->change_field_type('password','password');
		$c->change_field_type('username','readonly');
		$c->change_field_type('role','readonly');
		$c->required_fields('name','email');
		
		$c->unset_edit_fields('status','created','role_SSO');
		if($this->session->role_SSO!=""){$c->unset_edit_fields('status','created','role_SSO','password');} //if this user logs in using SSO, we cannot change password here
    $op3=$this->uri->segment(3);
    $op4=$this->uri->segment(4);
		if(!$op3||$op3=='read'||$op3=='delete'||$op3=='success'||$op3=='add'||$op4!=$this->session->id){redirect('users/profile/edit/'.$this->session->id);}
		
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
  public function _encryptPassword($post_array, $primary_key){
    if(!empty($post_array['password'])){
        // $post_array['password'] = $this->encrypt->encode($post_array['password'], 'super-secret-key');
        $post_array['password']=md5($post_array['password']);
    }else{
      unset($post_array['password']);
      //$post_array['password']=md5($post_array['password']);
    }
    return $post_array;
  }
	
	public function byNameOrMail($search=''){
		if($search==''){$search=$_GET['search'];}
		return json_encode($this->Usersmodel->byNameOrMail($search));
	}
	public function byMeeting($meetingId=''){
		if($meetingId==''){$meetingId=$_GET['meeting'];}
		return json_encode($this->Usersmodel->byMeeting($meetingId));
	}
	
  // public function getUserInfo($id){  
  //   $q = $this->db->get_where('users', array('id' => $id), 1);   
  //   if($this->db->affected_rows() > 0){  
  //     $row = $q->row();
  //     return $row;
  //   }else{  
  //     error_log('no user found getUserInfo('.$id.')');  
  //     return false;  
  //   } 
  // }
  // public function getUserInfoByEmail($email){  
  //    $q = $this->db->get_where('users', array('email' => $email), 1);   
  //    if($this->db->affected_rows() > 0){  
  //      $row = $q->row();  
  //      return $row;  
  //    }
  // }
  // public function insertToken($user_id){    
  //   $token = substr(sha1(rand()), 0, 30);   
  //   $date = date('Y-m-d');
  //   $string = array(  
  //       'token'=> $token,  
  //       'user_id'=>$user_id,  
  //       'created'=>$date  
  //   );  
  //   $query = $this->db->insert_string('tokens',$string);  
  //   $this->db->query($query);  
  //   return $token . $user_id;  
  // }  
  // public function isTokenValid($token){  
  //   $tkn = substr($token,0,30);  
  //   $uid = substr($token,30);     
  //     
  //   $q = $this->db->get_where('tokens', array(
  //     'tokens.token' => $tkn,   
  //     'tokens.user_id' => $uid), 1);               
  //         
  //   if($this->db->affected_rows() > 0){  
  //     $row = $q->row();         
  //       
  //     $created = $row->created;  
  //     $createdTS = strtotime($created);  
  //     $today = date('Y-m-d');   
  //     $todayTS = strtotime($today);  
  //       
  //     if($createdTS != $todayTS){ return false; }  
  //       
  //     $user_info = $this->getUserInfo($row->user_id);  
  //     return $user_info;  
  //   }else{  return false;  }  
  // }   
  // public function updatePassword($post){    
  //   $this->db->where('id_user', $post['id_user']);  
  //   $this->db->update('users', array('password' => $post['password']));      
  //   return true;  
  // }
	
	function jabatan($o='',$i=''){
		$c = new grocery_CRUD();
		$output['title'] = 'Jabatan';
		$output['session'] = $this->session;
		$c->set_table('user_jabatan');
		$c->set_relation('user','users','name');
		$output['output'] = $c->render();
		$this->load->view('common_crud',$output);
	}
}