<?php
function asset_url($url) {
	return base_url('assets/' . $url);
}