<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meetingsmodel extends CI_Model {
	public function getById($id) {
		$byId = $this->db->get_where('meetings', ['id' => $id]);
		return $byId->row();
	}
	function cleanAndInsertParticipants($meetingId, $input){
		$this->db->delete('meeting_participants',array('meeting'=>$meetingId));
		$data = json_decode($input);
		if(isset($input)&&$data!=''){
			foreach($data as $a){
				if(is_numeric($a)){
					$this->db->insert('meeting_participants',array(
						'meeting' => $meetingId,
						'name' => '',
						'user' => $a
					));
				}else{
					$ar = explode(' (',$a);
					if(count($ar)>1){
						$this->db->insert('meeting_participants',array(
							'meeting' => $meetingId,
							'name' => $ar[0],
							'email' => trim($ar[1],')'),
							'user' => 0
						));
					}else{
						$this->db->insert('meeting_participants',array(
							'meeting' => $meetingId,
							'name' => $a,
							'user' => 0
						));
					}
				}
			}
		}
	}
}