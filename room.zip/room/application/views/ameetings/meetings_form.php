<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Meetings <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">User <?php echo form_error('user') ?></label>
            <input type="text" class="form-control" name="user" id="user" placeholder="User" value="<?php echo $user; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Agenda <?php echo form_error('agenda') ?></label>
            <input type="text" class="form-control" name="agenda" id="agenda" placeholder="Agenda" value="<?php echo $agenda; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Room <?php echo form_error('room') ?></label>
            <input type="text" class="form-control" name="room" id="room" placeholder="Room" value="<?php echo $room; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">Start <?php echo form_error('start') ?></label>
            <input type="text" class="form-control" name="start" id="start" placeholder="Start" value="<?php echo $start; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">End <?php echo form_error('end') ?></label>
            <input type="text" class="form-control" name="end" id="end" placeholder="End" value="<?php echo $end; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Prev Meeting <?php echo form_error('prev_meeting') ?></label>
            <input type="text" class="form-control" name="prev_meeting" id="prev_meeting" placeholder="Prev Meeting" value="<?php echo $prev_meeting; ?>" />
        </div>
	    <div class="form-group">
            <label for="tinytext">Participants <?php echo form_error('participants') ?></label>
            <input type="text" class="form-control" name="participants" id="participants" placeholder="Participants" value="<?php echo $participants; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">No Undangan <?php echo form_error('no_undangan') ?></label>
            <input type="text" class="form-control" name="no_undangan" id="no_undangan" placeholder="No Undangan" value="<?php echo $no_undangan; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tgl Undangan <?php echo form_error('tgl_undangan') ?></label>
            <input type="text" class="form-control" name="tgl_undangan" id="tgl_undangan" placeholder="Tgl Undangan" value="<?php echo $tgl_undangan; ?>" />
        </div>
	    <div class="form-group">
            <label for="teks_undangan">Teks Undangan <?php echo form_error('teks_undangan') ?></label>
            <textarea class="form-control" rows="3" name="teks_undangan" id="teks_undangan" placeholder="Teks Undangan"><?php echo $teks_undangan; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="minute_of_meeting">Minute Of Meeting <?php echo form_error('minute_of_meeting') ?></label>
            <textarea class="form-control" rows="3" name="minute_of_meeting" id="minute_of_meeting" placeholder="Minute Of Meeting"><?php echo $minute_of_meeting; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="varchar">Attachment <?php echo form_error('attachment') ?></label>
            <input type="text" class="form-control" name="attachment" id="attachment" placeholder="Attachment" value="<?php echo $attachment; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Sumber Dana <?php echo form_error('sumber_dana') ?></label>
            <input type="text" class="form-control" name="sumber_dana" id="sumber_dana" placeholder="Sumber Dana" value="<?php echo $sumber_dana; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status <?php echo form_error('status') ?></label>
            <input type="text" class="form-control" name="status" id="status" placeholder="Status" value="<?php echo $status; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Status Note <?php echo form_error('status_note') ?></label>
            <input type="text" class="form-control" name="status_note" id="status_note" placeholder="Status Note" value="<?php echo $status_note; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">Created <?php echo form_error('created') ?></label>
            <input type="text" class="form-control" name="created" id="created" placeholder="Created" value="<?php echo $created; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">Modified <?php echo form_error('modified') ?></label>
            <input type="text" class="form-control" name="modified" id="modified" placeholder="Modified" value="<?php echo $modified; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('ameetings') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>