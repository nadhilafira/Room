<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Meetings Read</h2>
        <table class="table">
	    <tr><td>User</td><td><?php echo $user; ?></td></tr>
	    <tr><td>Agenda</td><td><?php echo $agenda; ?></td></tr>
	    <tr><td>Room</td><td><?php echo $room; ?></td></tr>
	    <tr><td>Start</td><td><?php echo $start; ?></td></tr>
	    <tr><td>End</td><td><?php echo $end; ?></td></tr>
	    <tr><td>Prev Meeting</td><td><?php echo $prev_meeting; ?></td></tr>
	    <tr><td>Participants</td><td><?php echo $participants; ?></td></tr>
	    <tr><td>No Undangan</td><td><?php echo $no_undangan; ?></td></tr>
	    <tr><td>Tgl Undangan</td><td><?php echo $tgl_undangan; ?></td></tr>
	    <tr><td>Teks Undangan</td><td><?php echo $teks_undangan; ?></td></tr>
	    <tr><td>Minute Of Meeting</td><td><?php echo $minute_of_meeting; ?></td></tr>
	    <tr><td>Attachment</td><td><?php echo $attachment; ?></td></tr>
	    <tr><td>Sumber Dana</td><td><?php echo $sumber_dana; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td>Status Note</td><td><?php echo $status_note; ?></td></tr>
	    <tr><td>Created</td><td><?php echo $created; ?></td></tr>
	    <tr><td>Modified</td><td><?php echo $modified; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('ameetings') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>