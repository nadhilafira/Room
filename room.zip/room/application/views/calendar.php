<?php 
$add = '
  <link rel="stylesheet" href="'.asset_url('plugins/easyAutocomplete/easy-autocomplete.min.css').'">
  <link rel="stylesheet" href="'.asset_url('plugins/fullcalendar/fullcalendar.min.css').'">
  <link rel="stylesheet" href="'.asset_url('plugins/fullcalendar/fullcalendar.print.css" media="print').'">';
$this->load->view('parts/header', ['title' => 'Calendar', 'add' => $add]); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <?php // require('calendarFilter.php'); ?>
        <!-- /.col -->
        <!--div class="col-md-9"-->
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-body no-padding">
              <!-- THE CALENDAR -->
              <div id="calendar"></div>
            </div> <!-- /.box-body -->
            <div style="padding:15px"><b>Backgroupd color</b> represents different room. <b>Border colors:</b> green (accepted), yellow (pending), red (rejected), black (status not selected).
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
		
		
<!-- modal -->
<div class="modal inmodal" id="modalNewBooking" tabindex="-1" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
		<div class="modal-content animated bounceInDown">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">
				<span aria-hidden="true"><i class="fa fa-remove"></i></span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">New Booking</h4>
			</div>
			<form name="formNewBooking" action="<?php base_url(); ?>" method="POST">
			<div class="modal-body">
				<!--input type="hidden" name="referrer" value="http://ijtech.eng.ui.ac.id/dashboard/submission/secretariat/status/1/page/1"-->
				<input type="text" class="form-control" name="date" id="formNewBooking_date" value="">
				<input type="text" class="form-control" placeholder="Starting time" name="start" value="">
				<input type="text" class="form-control" placeholder="Ending time" name="end" value="">
				<input type="text" id="newBooking_room" class="form-control" placeholder="Select room" name="room" value="">
				<input type="text" class="form-control" placeholder="Select users" name="user" value="">
				<input type="text" class="form-control" placeholder="Room usage" name="title" value="">
				<div class="form-group">
					<label>Note</label>
					<textarea name="note" rows="3" class="form-control" placeholder="Notes if any"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<input type="reset" name="reset" value="Cancel" class="btn btn-white" data-dismiss="modal">
				<input type="submit" name="move" value="Add" class="btn btn-primary action">
			</div>
			</form>
		</div>	
	</div>
</div>
<?php
// https://selectize.github.io/selectize.js/#demo-github atau http://easyautocomplete.com/guide#sec-templates

$add = "
<script src='".asset_url('plugins/easyAutocomplete/jquery.easy-autocomplete.min.js')."'></script>
<script src='".asset_url('plugins/fullcalendar/fullcalendar.min.js')."'></script>
<!-- Page specific script -->
<script>
	var options={
		url:'".base_url()."rooms/getJson',
		getValue:'id',
		template: {
			type: 'custom',
			method: function(value, item) {
				return item.name + ' <i style=\"color:green\">(' + item.capacity +')</i>';
			}
		}
	}
	$('#newBooking_room').easyAutocomplete(options);
  $(function () {

    /* initialize the external events
     -----------------------------------------------------------------*/
    function ini_events(ele) {
      ele.each(function () {

        // create an Event Object (http://arshaw.com/fullcalendar/docs/event_data/Event_Object/)
        // it doesn't need to have a start or end
        var eventObject = {
          title: $.trim($(this).text()) // use the element's text as the event title
        };

        // store the Event Object in the DOM element so we can get to it later
        $(this).data('eventObject', eventObject);

        // make the event draggable using jQuery UI
        $(this).draggable({
          zIndex: 1070,
          revert: true, // will cause the event to go back to its
          revertDuration: 0  //  original position after the drag
        });

      });
    }

    ini_events($('#external-events div.external-event'));

    var date = new Date();
    var d = date.getDate(),
        m = date.getMonth(),
        y = date.getFullYear();
    $('#calendar').fullCalendar({
			customButtons: {
				myCustomButton: {
					text: 'Delete',
					click: function() {
						alert('Drag an item here to delete');
					}
				}
      },
			header: {
        left: 'prev,next today myCustomButton',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      buttonText: {
        today: 'today',
        month: 'month',
        week: 'week',
        day: 'day'
      },
			eventDragStop: function(event,jsEvent) {
				var trashEl = jQuery('.fc-myCustomButton-button');
				var ofs = trashEl.offset();
				var x1 = ofs.left;
				var x2 = ofs.left + trashEl.outerWidth(true);
				var y1 = ofs.top;
				var y2 = ofs.top + trashEl.outerHeight(true);
				if (jsEvent.pageX >= x1 && jsEvent.pageX<= x2 && jsEvent.pageY >= y1 && jsEvent.pageY <= y2) {
					if(confirm('Are you sure?')){
						$.ajax({
							url     : '".base_url('meetings/dropAndDelete/')."'+event.id,
							type    : 'GET',
							dataType: 'JSON',
							beforeSend: function(){},
							success: function(data){
								$('#calendar').fullCalendar('removeEvents', event.id);
							},
							error: function (jqXHR, textStatus, errorThrown){
								alert('Delete failed');
							}
						});
					}
				}
			},
      events: ".json_encode($sesuatu).",
      editable: true,
			eventLimit: true, // allow 'more' link when too many events
			selectable: true,
			selectHelper: true,
			select: function(start, end){window.open('".base_url()."meetings/pop/add?w=1&dayStart='+moment(start).format('YYYY-MM-DD HH:mm')+'&dayEnd='+moment(end).format('YYYY-MM-DD HH:mm'),'targetWindow', 'toolbar=no, location=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=800, height=700');},
			eventClick: function(calEvent, jsEvent, view) {window.open('".base_url()."meetings/pop/edit/'+calEvent.id+'?w=1','targetWindow', 'toolbar=no, location=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=800, height=700');},
			eventDrop: function(event, delta, revertFunc) {editDropResize(event);},
			eventResize: function(event,dayDelta,minuteDelta,revertFunc) {editDropResize(event);},
    });
		
		
		
        function editDropResize(event){
            start = event.start.format('YYYY-MM-DD HH:mm:ss');
            if(event.end){
              end = event.end.format('YYYY-MM-DD HH:mm:ss');
            }else{
              end = start;
            }
            $.ajax({
                url     : '".base_url('meetings/reschedule')."',
                type    : 'POST',
                data    : 'id='+event.id+'&start='+start+'&end='+end,
                dataType: 'JSON',
                beforeSend: function(){},
                success: function(data){
									alert('Done');
                    // if(data.status){   
                        // $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html('Data success update');
                    // }else{
                        // $('.notification').removeClass('alert-primary').addClass('alert-danger').find('p').html('Data cant update');
                    // }
                },
                error: function (jqXHR, textStatus, errorThrown){
									alert('Error');
									// location.reload();
                    // $('.notification').removeClass('alert-primary').addClass('alert-danger').find('p').html('Wrong server, please save again');
                }
            });
        }

    /* ADDING EVENTS */
    var currColor = \"#3c8dbc\"; //Red by default
    //Color chooser button
    var colorChooser = $(\"#color-chooser-btn\");
    $(\"#color-chooser > li > a\").click(function (e) {
      e.preventDefault();
      //Save color
      currColor = $(this).css(\"color\");
      //Add color effect to button
      $('#add-new-event').css({\"background-color\": currColor, \"border-color\": currColor});
    });
    $(\"#add-new-event\").click(function (e) {
      e.preventDefault();
      //Get value and make sure it is not null
      var val = $(\"#new-event\").val();
      if (val.length == 0) {
        return;
      }

      //Create events
      var event = $(\"<div />\");
      event.css({\"background-color\": currColor, \"border-color\": currColor, \"color\": \"#fff\"}).addClass(\"external-event\");
      event.html(val);
      $('#external-events').prepend(event);

      //Add draggable funtionality
      ini_events(event);

      //Remove event from text input
      $(\"#new-event\").val(\"\");
    });
  });
$(document).ready(function() {
	$('#calendar').fullCalendar('option', 'height',$(window).height()-200);
});
$(window).resize(function() {
	$('#calendar').fullCalendar('option', 'height',$(window).height()-200);
});
</script>";
if($u!=''){
	$this->session->unset_userdata('updatedDate');
	$add .= "<script>
		$(document).ready(function() {
			$('#calendar').fullCalendar('changeView','agendaDay');
			$('#calendar').fullCalendar('gotoDate', moment('".$u."')); 
		});
	</script>";
}
$this->load->view('parts/footer', ['add' => $add]); ?>
