<?php 
$add = '
  <link rel="stylesheet" href="'.asset_url('plugins/easyAutocomplete/easy-autocomplete.min.css').'">
  <link rel="stylesheet" href="'.asset_url('plugins/fullcalendar/fullcalendar.min.css').'">
  <link rel="stylesheet" href="'.asset_url('plugins/fullcalendar/fullcalendar.print.css').'" media="print">
	<!-- 2 css dari CalendarCI: -->
  <link rel="stylesheet" href="'.asset_url('css/style.css').'">
  <link rel="stylesheet" href="'.asset_url('plugins/datepicker/datepicker3.css').'">
	';
$forDynModal = '';
$aaaaaa='
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/css/jquery_plugins/chosen/chosen.css" />
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/themes/bootstrap/css/bootstrap/bootstrap.min.css" />
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/themes/bootstrap/css/font-awesome/css/font-awesome.min.css" />
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/themes/bootstrap/css/common.css" />
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/themes/bootstrap/css/general.css" />
	<link type="text/css" rel="stylesheet" href="'.asset_url('grocery_crud').'/themes/bootstrap/css/add-edit-form.css" />
	<script src="'.asset_url('grocery_crud').'/js/jquery-1.11.1.min.js"></script>
	<script src="'.asset_url('grocery_crud').'/js/jquery_plugins/jquery.chosen.min.js"></script>
	<script src="'.asset_url('grocery_crud').'/js/jquery_plugins/config/jquery.chosen.config.js"></script>
	<script src="'.asset_url('grocery_crud').'/themes/bootstrap/build/js/global-libs.min.js"></script>
	<script src="'.asset_url('grocery_crud').'/themes/bootstrap/js/form/add.min.js"></script>
';
$this->load->view('parts/header', ['title' => 'Calendar', 'add' => $add, 'forDynModal'=>$forDynModal]); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <div class="box box-solid">
            <div class="box-header with-border">
              <h4 class="box-title">Filter</h4>
            </div>
            <div class="box-body">
              <!-- the events -->
							room (dropdown nama2 ruang yg ada)
							<br>status (dropdown pilihan sesuai enum di kolom status di tabel bookings )
							<br>user (kalo bisa pake typehead)
							<br>time range (kalo bisa dalam bentuk slider)
							<br>button apply & clear
							<br>
							<br>Di calendarnya, harus bisa click to edit or delete a booking, click empty area to add a booking, drag to move to other date, and stretch change duration of a booking.
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-body no-padding">
              <!-- THE CALENDAR -->
              <div id="calendarIO"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
		
		
<!-- modal -->
<div class="modal inmodal fade" id="modalNewBooking" tabindex="-1" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
		<div class="modal-content animated bounceInDown">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">
				<span aria-hidden="true"><i class="fa fa-remove"></i></span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">New Booking</h4>
			</div>
			<form name="formNewBooking" action="<?php base_url(); ?>" method="POST">
			<div class="modal-body">
				<!--input type="hidden" name="referrer" value="http://ijtech.eng.ui.ac.id/dashboard/submission/secretariat/status/1/page/1"-->
				<input type="text" class="form-control" name="date" id="formNewBooking_date" value="">
				<input type="text" class="form-control" placeholder="Starting time" name="start" value="">
				<input type="text" class="form-control" placeholder="Ending time" name="end" value="">
				<input type="text" id="newBooking_room" class="form-control" placeholder="Select room" name="room" value="">
				<input type="text" class="form-control" placeholder="Select users" name="user" value="">
				<input type="text" class="form-control" placeholder="Room usage" name="title" value="">
				<div class="form-group">
					<label>Note</label>
					<textarea name="note" rows="3" class="form-control" placeholder="Notes if any"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<input type="reset" name="reset" value="Cancel" class="btn btn-white" data-dismiss="modal">
				<input type="submit" name="move" value="Add" class="btn btn-primary action">
			</div>
			</form>
		</div>	
	</div>
</div>

<!-- modal dari CalendarCI -->
                                <div class="modal fade" id="create_modal_0" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <form class="form-horizontal" method="POST" action="POST" id="form_create">
                                                <input type="hidden" name="calendar_id" value="0">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    <h4 class="modal-title" id="myModalLabel">Create calendar event</h4>
                                                </div>
                                                <div class="modal-body">

                                                    <div class="form-group">
                                                         <div class="alert alert-danger" style="display: none;"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-2">Title  <span class="required"> * </span></label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="title" class="form-control" placeholder="Title">
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="control-label col-sm-2">Description</label>
                                                        <div class="col-sm-10">
                                                            <textarea name="description" rows="3" class="form-control"  placeholder="Enter description"></textarea>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="color" class="col-sm-2 control-label">Color</label>
                                                        <div class="col-sm-10">
                                                            <select name="color" class="form-control">
                                                                <option value="">Choose</option>
                                                                <option style="color:#0071c5;" value="#0071c5">&#9724; Dark blue</option>
                                                                <option style="color:#40E0D0;" value="#40E0D0">&#9724; Turquoise</option>
                                                                <option style="color:#c50055;" value="#c50055">&#9724; Pink</option>                       
                                                                <option style="color:#FFD700;" value="#FFD700">&#9724; Yellow</option>
                                                                <option style="color:#FF8C00;" value="#FF8C00">&#9724; Orange</option>
                                                                <option style="color:#FF0000;" value="#FF0000">&#9724; Red</option>
                                                                <option style="color:#000;" value="#000">&#9724; Black</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="control-label col-sm-2">Start Date</label>
                                                        <div class="col-sm-10">
                                                            <div class="input-group input-medium date date-picker" data-date-format="yyyy-mm-dd" data-date-viewmode="years">
                                                                <input type="text" name="start_date" class="form-control" readonly>
                                                                <span class="input-group-addon"><i class="fa fa-calendar font-dark"></i></span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="control-label col-sm-2">End Date</label>
                                                        <div class="col-sm-10">
                                                            <div class="input-group input-medium date date-picker" data-date-format="yyyy-mm-dd" data-date-viewmode="years">
                                                                <input type="text" name="end_date" class="form-control" readonly>
                                                                <span class="input-group-addon"><i class="fa fa-calendar font-dark"></i></span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <a href="javascript::void" class="btn default" data-dismiss="modal">Cancel</a>
                                                    <a class="btn btn-danger delete_calendar" style="display: none;">Delete</a>
                                                    <button type="submit" class="btn green">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
																
		<div class="modal fade" id="create_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<?php if(isset($showModal)){echo $showModal['content'];}else{echo 'Loading...';} ?>
				</div>
			</div>
		</div>



<?php
// https://selectize.github.io/selectize.js/#demo-github atau http://easyautocomplete.com/guide#sec-templates

$add = "
<script src='".asset_url('plugins/easyAutocomplete/jquery.easy-autocomplete.min.js')."'></script>
<script src='".asset_url('plugins/fullcalendar/fullcalendar.min.js')."'></script>
<!-- 1 js dari CalendarCI: -->
<script src='".asset_url('plugins/datepicker/bootstrap-datepicker.js')."'></script>

<!-- Page specific script -->
<script>
	var options={
		url:'".base_url()."rooms/getJson',
		getValue:'id',
		template: {
			type: 'custom',
			method: function(value, item) {
				return item.name + ' <i style=\"color:green\">(' + item.capacity +')</i>';
			}
		}
	}
	$('#newBooking_room').easyAutocomplete(options);
  $(function () {

    /* initialize the external events
     -----------------------------------------------------------------*/
    function ini_events(ele) {
      ele.each(function () {

        // create an Event Object (http://arshaw.com/fullcalendar/docs/event_data/Event_Object/)
        // it doesn't need to have a start or end
        var eventObject = {
          title: $.trim($(this).text()) // use the element's text as the event title
        };

        // store the Event Object in the DOM element so we can get to it later
        $(this).data('eventObject', eventObject);

        // make the event draggable using jQuery UI
        $(this).draggable({
          zIndex: 1070,
          revert: true, // will cause the event to go back to its
          revertDuration: 0  //  original position after the drag
        });

      });
    }

    ini_events($('#external-events div.external-event'));

    /* initialize the calendar
     -----------------------------------------------------------------*/
    //Date for the calendar events (dummy data)
    var date = new Date();
    var d = date.getDate(),
        m = date.getMonth(),
        y = date.getFullYear();
    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      buttonText: {
        today: 'today',
        month: 'month',
        week: 'week',
        day: 'day'
      },
      //list of events
      events: ".json_encode($sesuatu).",
      editable: true,
      droppable: true, // this allows things to be dropped onto the calendar !!!
			dayClick: function(date, jsEvent, view) {
				//alert('Munculkan interface utk add bookings di tgl ini (pilih jam start & end, ruangan, user, dan keperluan) | Clicked on: ' + date.format() +
					//' | '+'Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY +
					//' | '+'Current view: ' + view.name);
				$('#formNewBooking_date').val(date.format() + ' tambahin datepicker!');
				$('#modalNewBooking').modal('show');
				// change the day's background color just for fun
				//$(this).css('background-color', 'red');
			},
			eventClick: function(info) {
				alert('Event: ' + info.event.title);
				//info.el.style.borderColor = 'red';
			},
			eventDrop: function(event, delta, revertFunc) {
				alert(event.title + ' was dropped on ' + event.start.format());
				if (!confirm('Are you sure about this change?')) {
					revertFunc();
				}
			},
			eventResize: function(event, delta, revertFunc) {
				alert(event.title + ' end is now ' + event.end.format());
				if (!confirm('is this okay?')) {
					revertFunc();
				}
			},
			eventClick: function(calEvent, jsEvent, view) {
				alert('Event: ' + calEvent.title +' | '+ 'Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY +' | '+'View: ' + view.name);
				$(this).css('border-color', 'red'); // change the border color just for fun
			},
			
      drop: function (date, allDay) { // this function is called when something is dropped

        // retrieve the dropped element's stored Event Object
        var originalEventObject = $(this).data('eventObject');

        // we need to copy it, so that multiple events don't have a reference to the same object
        var copiedEventObject = $.extend({}, originalEventObject);

        // assign it the date that was reported
        copiedEventObject.start = date;
        copiedEventObject.allDay = allDay;
        copiedEventObject.backgroundColor = $(this).css(\"background-color\");
        copiedEventObject.borderColor = $(this).css(\"border-color\");

        // render the event on the calendar
        // the last \'true\' argument determines if the event \"sticks\" (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
        $('#calendar').fullCalendar('renderEvent', copiedEventObject, true);

        // is the \"remove after drop\" checkbox checked?
        if ($('#drop-remove').is(':checked')) {
          // if so, remove the element from the \"Draggable Events\" list
          $(this).remove();
        }

      }
    });

    /* ADDING EVENTS */
    var currColor = \"#3c8dbc\"; //Red by default
    //Color chooser button
    var colorChooser = $(\"#color-chooser-btn\");
    $(\"#color-chooser > li > a\").click(function (e) {
      e.preventDefault();
      //Save color
      currColor = $(this).css(\"color\");
      //Add color effect to button
      $('#add-new-event').css({\"background-color\": currColor, \"border-color\": currColor});
    });
    $(\"#add-new-event\").click(function (e) {
      e.preventDefault();
      //Get value and make sure it is not null
      var val = $(\"#new-event\").val();
      if (val.length == 0) {
        return;
      }

      //Create events
      var event = $(\"<div />\");
      event.css({\"background-color\": currColor, \"border-color\": currColor, \"color\": \"#fff\"}).addClass(\"external-event\");
      event.html(val);
      $('#external-events').prepend(event);

      //Add draggable funtionality
      ini_events(event);

      //Remove event from text input
      $(\"#new-event\").val(\"\");
    });
  });
</script>

<!-- dari CalendarCI: -->
<script>
        var get_data        = '".$get_data."';
        var backend_url     = '".base_url()."';

        $(document).ready(function() {
            $('.date-picker').datepicker();
            $('#calendarIO').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,basicWeek,basicDay'
                },
                defaultDate: moment().format('YYYY-MM-DD'),
                editable: true,
                eventLimit: true, // allow 'more' link when too many events
                selectable: true,
                selectHelper: true,
                select: function(start, end) {
									window.open(backend_url+'meetings/index/add?w=1&dayStart='+moment(start).format('YYYY-MM-DD')+'&dayEnd='+moment(end).format('YYYY-MM-DD'),'targetWindow', 'toolbar=no, location=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=800, height=700');
                     // $('#create_modal input[name=start_date]').val(moment(start).format('YYYY-MM-DD'));
                     // $('#create_modal input[name=end_date]').val(moment(end).format('YYYY-MM-DD'));
										//ruki edit START
                    // $('#create_modal').html('<div class=\'modal-dialog modal-lg\' role=\'document\'><div class=\'modal-content\'><div class=\'modal-header\'><button type=\'button\' class=\'close\' data-dismiss=\'modal\' aria-label=\'Close\'><span aria-hidden=\'true\'>&times;</span></button><h4 class=\'modal-title\' id=\'myModalLabel\'>Loading...</h4></div></div></div>');
										//ruki edit END
                    // $('#create_modal').load(backend_url+'meetings/index/add?m=1');
                    // $('#create_modal').modal('show');
										// $('#field-user').chosen();
                    // save();
                    $('#calendarIO').fullCalendar('unselect');
                },
                eventDrop: function(event, delta, revertFunc) { // si changement de position
                    editDropResize(event);
                },
                eventResize: function(event,dayDelta,minuteDelta,revertFunc) { // si changement de longueur
                    editDropResize(event);
                },
                eventClick: function(event, element)
                {
                    deteil(event);
                    editData(event);
                    deleteData(event);
                },
                events: JSON.parse(get_data)
            });
        });

        $(document).on('submit', '#form_create', function(){
            var element = $(this);
            var eventData;
            $.ajax({
                url     : backend_url+'calendar2/save',
                type    : element.attr('method'),
                data    : element.serialize(),
                dataType: 'JSON',
                beforeSend: function()
                {
                    element.find('button[type=submit]').html('<i class=\'fa fa-spinner fa-spin\' aria-hidden=\'true\'></i>');
                },
                success: function(data)
                {
                    if(data.status)
                    {   
                        eventData = {
                            id          : data.id,
                            title       : $('#create_modal input[name=title]').val(),
                            description : $('#create_modal textarea[name=description]').val(),
                            start       : moment($('#create_modal input[name=start_date]').val()).format('YYYY-MM-DD HH:mm:ss'),
                            end         : moment($('#create_modal input[name=end_date]').val()).format('YYYY-MM-DD HH:mm:ss'),
                            color       : $('#create_modal select[name=color]').val()
                        };
                        $('#calendarIO').fullCalendar('renderEvent', eventData, true); // stick? = true
                        $('#create_modal').modal('hide');
                        element[0].reset();
                        $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html(data.notif);
                    }
                    else
                    {
                        element.find('.alert').css('display', 'block');
                        element.find('.alert').html(data.notif);
                    }
                    element.find('button[type=submit]').html('Submit');
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    element.find('button[type=submit]').html('Submit');
                    element.find('.alert').css('display', 'block');
                    element.find('.alert').html('Wrong server, please save again');
                }         
            });
            return false;
        })

        function editDropResize(event)
        {
            start = event.start.format('YYYY-MM-DD HH:mm:ss');
            if(event.end)
            {
                end = event.end.format('YYYY-MM-DD HH:mm:ss');
            }
            else
            {
                end = start;
            }
         
            $.ajax({
                url     : backend_url+'calendar2/save',
                type    : 'POST',
                data    : 'calendar_id='+event.id+'&title='+event.title+'&start_date='+start+'&end_date='+end,
                dataType: 'JSON',
                beforeSend: function()
                {
                },
                success: function(data)
                {
                    if(data.status)
                    {   
                        $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html('Data success update');
                    }
                    else
                    {
                        $('.notification').removeClass('alert-primary').addClass('alert-danger').find('p').html('Data cant update');
                    }
             
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    $('.notification').removeClass('alert-primary').addClass('alert-danger').find('p').html('Wrong server, please save again');
                }         
            });
        }

        function save()
        {
            $('#form_create').submit(function(){
                var element = $(this);
                var eventData;
                $.ajax({
                    url     : backend_url+'calendar2/save',
                    type    : element.attr('method'),
                    data    : element.serialize(),
                    dataType: 'JSON',
                    beforeSend: function()
                    {
                        element.find('button[type=submit]').html('<i class=\'fa fa-spinner fa-spin\' aria-hidden=\'true\'></i>');
                    },
                    success: function(data)
                    {
                        if(data.status)
                        {   
                            eventData = {
                                id          : data.id,
                                title       : $('#create_modal input[name=title]').val(),
                                description : $('#create_modal textarea[name=description]').val(),
                                start       : moment($('#create_modal input[name=start_date]').val()).format('YYYY-MM-DD HH:mm:ss'),
                                end         : moment($('#create_modal input[name=end_date]').val()).format('YYYY-MM-DD HH:mm:ss'),
                                color       : $('#create_modal select[name=color]').val()
                            };
                            $('#calendarIO').fullCalendar('renderEvent', eventData, true); // stick? = true
                            $('#create_modal').modal('hide');
                            element[0].reset();
                            $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html(data.notif);
                        }
                        else
                        {
                            element.find('.alert').css('display', 'block');
                            element.find('.alert').html(data.notif);
                        }
                        element.find('button[type=submit]').html('Submit');
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        element.find('button[type=submit]').html('Submit');
                        element.find('.alert').css('display', 'block');
                        element.find('.alert').html('Wrong server, please save again');
                    }         
                });
                return false;
            })
        }

        function deteil(event)
        {
            $('#create_modal input[name=calendar_id]').val(event.id);
            $('#create_modal input[name=start_date]').val(moment(event.start).format('YYYY-MM-DD'));
            $('#create_modal input[name=end_date]').val(moment(event.end).format('YYYY-MM-DD'));
            $('#create_modal input[name=title]').val(event.title);
            $('#create_modal input[name=description]').val(event.description);
            $('#create_modal select[name=color]').val(event.color);
            $('#create_modal .delete_calendar').show();
            $('#create_modal').modal('show');
        }

        function editData(event)
        {
            $('#form_create').submit(function(){
                var element = $(this);
                var eventData;
                $.ajax({
                    url     : backend_url+'calendar2/save',
                    type    : element.attr('method'),
                    data    : element.serialize(),
                    dataType: 'JSON',
                    beforeSend: function()
                    {
                        element.find('button[type=submit]').html('<i class=\'fa fa-spinner fa-spin\' aria-hidden=\'true\'></i>');
                    },
                    success: function(data)
                    {
                        if(data.status)
                        {   
                            event.title         = $('#create_modal input[name=title]').val();
                            event.description   = $('#create_modal textarea[name=description]').val();
                            event.start         = moment($('#create_modal input[name=start_date]').val()).format('YYYY-MM-DD HH:mm:ss');
                            event.end           = moment($('#create_modal input[name=end_date]').val()).format('YYYY-MM-DD HH:mm:ss');
                            event.color         = $('#create_modal select[name=color]').val();
                            $('#calendarIO').fullCalendar('updateEvent', event);

                            $('#create_modal').modal('hide');
                            element[0].reset();
                            $('#create_modal input[name=calendar_id]').val(0)
                            $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html(data.notif);
                        }
                        else
                        {
                            element.find('.alert').css('display', 'block');
                            element.find('.alert').html(data.notif);
                        }
                        element.find('button[type=submit]').html('Submit');
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        element.find('button[type=submit]').html('Submit');
                        element.find('.alert').css('display', 'block');
                        element.find('.alert').html('Wrong server, please save again');
                    }         
                });
                return false;
            })
        }

        function deleteData(event)
        {
            $('#create_modal .delete_calendar').click(function(){
                $.ajax({
                    url     : backend_url+'calendar2/delete',
                    type    : 'POST',
                    data    : 'id='+event.id,
                    dataType: 'JSON',
                    beforeSend: function()
                    {
                    },
                    success: function(data)
                    {
                        if(data.status)
                        {   
                            $('#calendarIO').fullCalendar('removeEvents',event._id);
                            $('#create_modal').modal('hide');
                            $('#form_create')[0].reset();
                            $('#create_modal input[name=calendar_id]').val(0)
                            $('.notification').removeClass('alert-danger').addClass('alert-primary').find('p').html(data.notif);
                        }
                        else
                        {
                            $('#form_create').find('.alert').css('display', 'block');
                            $('#form_create').find('.alert').html(data.notif);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        $('#form_create').find('.alert').css('display', 'block');
                        $('#form_create').find('.alert').html('Wrong server, please save again');
                    }         
                });
            })
        }

    </script>
</script>
";
$this->load->view('parts/footer', ['add' => $add]); ?>
?>