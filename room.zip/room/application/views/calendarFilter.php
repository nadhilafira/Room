				<div class="col-md-3">
					<div class="box box-solid">
            <div class="box-header with-border">
              <h4 class="box-title">Filter</h4>
            </div>
            <div class="box-body">
							room (dropdown nama2 ruang yg ada)
							<br>status (dropdown pilihan sesuai enum di kolom status di tabel bookings )
							<br>user (kalo bisa pake typehead)
							<br>time range (kalo bisa dalam bentuk slider)
							<br>button apply & clear
							<br>
							<br>Di calendarnya, harus bisa click to edit or delete a booking, click empty area to add a booking, drag to move to other date, and stretch change duration of a booking.
            </div>
          </div>
        </div>