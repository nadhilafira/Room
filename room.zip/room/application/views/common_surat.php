<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "https://www.w3.org/TR/html4/strict.dtd">
<html lang="id"><head><meta http-equiv=Content-Type content="text/html; charset=UTF-8">
<title></title>
<style type="text/css">
body,td,div,p,a,input {font-family: times}
body, td {font-size:13px} a:link, a:active {color:#1155CC; text-decoration:none} a:hover {text-decoration:underline; cursor: pointer} a:visited{color:##6611CC} img{border:0px} pre { white-space: pre; white-space: -moz-pre-wrap; white-space: -o-pre-wrap; white-space: pre-wrap; word-wrap: break-word; max-width: 800px; overflow: auto;} .logo { left: -7px; position: relative; }
</style>
<body>

<?php 
//css
echo $body;
//javascript print

// if(!isset($scriptBeforeJQuery)){$scriptBeforeJQuery = '';}
// if(!isset($scriptAfterJQuery)){$scriptAfterJQuery = '';}
// if(!isset($scriptFooter)){$scriptFooter = '';}
// $this->load->view('parts/header',['add' => $scriptBeforeJQuery, 'add2' => $scriptAfterJQuery]); 
// $this->load->view('parts/footer',['add'=>$scriptFooter]);

?>
<script type="text/javascript">// <![CDATA[
document.body.onload=function(){document.body.offsetHeight;window.print()};
// ]]></script>
</body>
</html>