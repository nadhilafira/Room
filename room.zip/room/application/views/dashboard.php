<?php 
$chartScript ='';
if(!isset($scriptBeforeJQuery)){$scriptBeforeJQuery = '';}
if(!isset($scriptAfterJQuery)){$scriptAfterJQuery = '';}
if(!isset($scriptFooter)){$scriptFooter = '';}
$this->load->view('parts/header',['add' => $scriptBeforeJQuery, 'add2' => $scriptAfterJQuery]); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon"><i class="fa fa-building"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Rooms</span>
              <span class="info-box-number"><?=$data['numRoom']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-blue"><i class="fa fa-group"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Users</span>
              <span class="info-box-number"><?=$data['numAllUser']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-calendar"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Bookings Made / Approved</span>
              <span class="info-box-number"><?=$data['numAllBookings']?> / <?=$data['numAllApprovedBookings']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-check"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Meetings Done</span>
              <span class="info-box-number"><?=$data['numMeetingDone']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
			
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-briefcase"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Average number of meetings weekly</span>
              <span class="info-box-number"><?=$data['avgNumMeetingWeekly']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-envelope"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Average invited people per meeting</span>
              <span class="info-box-number"><?=$data['avgInvitedUser']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-hourglass"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Average Days Before Decision</span>
              <span class="info-box-number"><?=$data['waitingApprovalDelay']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-check-square"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Attendance Percentage</span>
              <span class="info-box-number"><?=$data['attendanceRatePerMeeting']?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
			
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">More Recap</h3>

              <!--div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div-->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-6">
                  <!--p class="text-center"><strong>1 Jan, 2014 - 30 Jul, 2014</strong></p>
                  <div class="chart"><canvas id="salesChart" style="height: 180px;"></canvas></div-->
                </div>
                <!-- /.col -->
                <div class="col-md-3">
                  <p class="text-center"><strong>Room Process</strong></p>
                  <div class="progress-group">
                    <span class="progress-text">Menanti verifikasi</span>
                    <span class="progress-number"><b><?=$data['numAllPendingBookings']?></b>/<?=$data['numAllBookings']?></span>
                    <div class="progress sm">
                      <div class="progress-bar progress-bar-warning" style="width: <?php echo 100*$data['numAllPendingBookings']/$data['numAllBookings']; ?>%"></div>
                    </div>
                  </div>
                  <div class="progress-group">
                    <span class="progress-text">Ditolak</span>
                    <span class="progress-number"><b><?=$data['numAllRejectedBookings']?></b>/<?=$data['numAllBookings']?></span>
                    <div class="progress sm">
                      <div class="progress-bar progress-bar-error" style="width: <?php echo 100*$data['numAllRejectedBookings']/$data['numAllBookings']; ?>%"></div>
                    </div>
                  </div>
                  <div class="progress-group">
                    <span class="progress-text">Diizinkan</span>
                    <span class="progress-number"><b><?=$data['numAllApprovedBookings']?></b>/<?=$data['numAllBookings']?></span>
                    <div class="progress sm">
                      <div class="progress-bar progress-bar-success" style="width: <?php echo 100*$data['numAllApprovedBookings']/$data['numAllBookings']; ?>%"></div>
                    </div>
                  </div>
									
									<?php
									// echo '<pre>';
									// print_r($data);
									// echo '</pre>';
									?>
                </div>
                
                <div class="col-md-3">
									<p class="text-center"><strong>Last Month's Bookings Per Room</strong><br>(approved/Booked)</p>
									<?php
										if(count($data['jmlMeetingLastMonthEachRoom'])>0){
											foreach($data['jmlMeetingLastMonthEachRoom'] as $room){ ?>
                  <div class="progress-group">
                    <span class="progress-text"><?=$room->name?></span>
                    <span class="progress-number"><b><?=$room->approved?></b>/<?=$room->applied?></span>
                    <div class="progress sm">
                      <div class="progress-bar progress-bar-success" style="width: <?php echo 100*$room->approved/$room->applied; ?>%"></div>
                    </div>
                  </div>
									<?php }} ?>
								</div>
								
                <!-- /.col -->
              </div>
							
              <div class="row">
								<?php 
								if(count($data['numMeetingWeekly'])>0){
									$chartScript .= '
										var numMeetingWeeklyCanvas = $("#numMeetingWeekly").get(0).getContext("2d");
										var numMeetingWeekly = new Chart(numMeetingWeeklyCanvas);
										var numMeetingWeeklyData = {
											labels: ["Pekan ke-'.implode('","Pekan ke-',array_column($data['numMeetingWeekly'],'week')).'"],
											datasets: [{
													label: "Applied",
													fillColor: "orange",
													data: ['.implode(',',array_column($data['numMeetingWeekly'],'waiting')).']
												},{
													label: "Approved",
													fillColor: "green",
													data: ['.implode(',',array_column($data['numMeetingWeekly'],'approved')).']
												},]
										};
										var numMeetingWeeklyOptions = {
											showScale: true,
											scaleShowGridLines: false,
											maintainAspectRatio: true,
											responsive: true
										};
										numMeetingWeekly.Bar(numMeetingWeeklyData,numMeetingWeeklyOptions);
									';
								?>
                <div class="col-md-6">
                  <p class="text-center">
                    <strong>Number of meetings last 5 weeks</strong>
                  </p>
                  <div class="chart">
                    <canvas id="numMeetingWeekly" style="height: 180px;"></canvas>
                  </div>
                </div>
								<?php } ?>
								<?php 
								if(count($data['numMeetingMonthly'])>0){
									$chartScript .= '
										var numMeetingMonthlyCanvas = $("#numMeetingMonthly").get(0).getContext("2d");
										var numMeetingMonthly = new Chart(numMeetingMonthlyCanvas);
										var numMeetingMonthlyData = {
											labels: ["Bulan ke-'.implode('","Bulan ke-',array_column($data['numMeetingMonthly'],'month')).'"],
											datasets: [{
													label: "Applied",
													fillColor: "orange",
													data: ['.implode(',',array_column($data['numMeetingMonthly'],'waiting')).']
												},{
													label: "Approved",
													fillColor: "green",
													data: ['.implode(',',array_column($data['numMeetingMonthly'],'approved')).']
												},]
										};
										var numMeetingMonthlyOptions = {
											showScale: true,
											scaleShowGridLines: false,
											maintainAspectRatio: true,
											responsive: true
										};
										numMeetingMonthly.Bar(numMeetingMonthlyData,numMeetingMonthlyOptions);
									';
								?>
                <div class="col-md-6">
                  <p class="text-center">
                    <strong>Number of meetings last 3 months</strong>
                  </p>
                  <div class="chart">
                    <canvas id="numMeetingMonthly" style="height: 180px;"></canvas>
                  </div>
                </div>
								<?php } ?>
              </div>
							
							
							
              
            </div>
            <!-- ./box-body -->
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
<?php 
$data = ["add" => "<!-- ChartJS 1.0.1 -->
<script src='".asset_url('plugins/chartjs/Chart.min.js')."'></script>
<script src='".asset_url('dist/js/pages/dashboard2.js')."'></script><script>".$chartScript."</script>"];
$this->load->view('parts/footer',$data); ?>
