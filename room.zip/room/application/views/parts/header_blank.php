<!DOCTYPE html>
<html>
<?php require('head.php'); ?>

<body class="hold-transition skin-blue sidebar-collapse">
<div class="wrapper">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title;?>
      </h1>
    </section>
