<?php
$fromTemplate .= "<h1>Departemen Teknik Elektro</h1> <h2>Fakultas Teknik, Universitas Indonesia</h2> </center> <hr>";
?>
